#ifndef HEADERS_H
#define HEADERS_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <algorithm>

#include <list>
#include <vector>
#include <queue>
#include <set>

#include <unistd.h>
#include <stdint.h>

using namespace std;

#include "debug.h"

#include "time.h"

//#include "test_time.h"

/*
#ifndef __clang__
  #define typeof(x) decltype(x)
#endif
*/

// Abreviaciones
//#define forall(i,a,b)  for(int i=(int)a;i<(int)b;i++)
//#ifdef __clang__
  #define foreach(v,c)   for(typeof ((c).begin()) v=(c).begin();v!=(c).end();++v)
//#else
//  #define foreach(v,c)   for(decltype ((c).begin()) v=(c).begin();v!=(c).end();++v)
//#endif
#define pb             push_back
#define sz(a)          ((int)(a.size()))
#define mp             make_pair

typedef unsigned int uint;
typedef vector<bool> vbool;
typedef vector<vbool> vvbool;
typedef vector<uint> vuint;
typedef set<uint> suint;
typedef vector<suint> vsuint;

#endif
