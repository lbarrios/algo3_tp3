#ifndef __TIME_TEST_H__
#define __TIME_TEST_H__

#include <time.h>
#include <stdint.h>
#include <iostream>

using namespace std;

typedef struct {
	struct timespec inicioParteA;
	struct timespec inicioParteB;
	struct timespec finParteA;
	struct timespec finParteB;
	int64_t segundosDeEjecucion;
	int64_t nanosegundosDeEjecucion;
	double milisegundosA;
	double milisegundosB;
}time_test_t;


time_test_t test;


inline void get_init_A(time_test_t &test)
{
	clock_gettime( CLOCK_REALTIME, &test.inicioParteA);
}

inline void get_init_B(time_test_t &test)
{
	clock_gettime( CLOCK_REALTIME, &test.inicioParteB);
}

inline void get_end_A(time_test_t &test)
{
	clock_gettime( CLOCK_REALTIME, &test.finParteA);
}

inline void get_end_B(time_test_t &test)
{
	clock_gettime( CLOCK_REALTIME, &test.finParteB);
}

inline void process_and_print(int size,time_test_t &test)
{
	double init,end;
	init = double(test.inicioParteA.tv_sec);
	init = init * (double)1000;
	end = double(test.finParteA.tv_sec);
	end= end * (double)1000;
	test.milisegundosA = end - init;
	init = double(test.inicioParteA.tv_nsec);
	init = init * 1e-6;
	end = double(test.finParteA.tv_nsec);
	end= end * 1e-6;
	test.milisegundosA += end - init;

	init = double(test.inicioParteB.tv_sec);
	init = init * (double)1000;
	end = double(test.finParteB.tv_sec);
	end= end * (double)1000;
	test.milisegundosB = end - init;
	init = double(test.inicioParteB.tv_nsec);
	init = init * 1e-6;
	end = double(test.finParteB.tv_nsec);
	end= end * 1e-6;
	test.milisegundosB += end - init;
	test.nanosegundosDeEjecucion = test.finParteB.tv_nsec - test.inicioParteA.tv_nsec; 
	test.segundosDeEjecucion = test.finParteB.tv_sec - test.inicioParteA.tv_sec;
	cout.precision(4);
	cout << size << " " << test.milisegundosA << " " << test.milisegundosB << " " << test.milisegundosA + test.milisegundosB << " " << (int64_t) (test.nanosegundosDeEjecucion + (test.segundosDeEjecucion*(1e9))) << endl;

}

#endif

