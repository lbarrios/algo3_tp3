#ifndef __DEBUG_H__
/* Funciones para debuggear */
#define __DEBUG_H__

#include "../DebugSingleton.h"

#ifdef DEBUG
  //#undef DEBUG
  #ifdef DEBUG2
    #define DEBUGP(x) Debug::getInstance()->getDebug() <<"VAR: "<<#x<<" = "<<x\
      <<"   <--  [ "<<__func__<<" @ "<<__FILE__<<" ("<<__LINE__<<") ]"\
      <<std::endl
    #define DEBUG2_PRINT(x) Debug::getInstance()->getDebug() << x << std::endl
	  #define DEBUG2_TABULADO(x,y) \
 	   for(int iiiiii=0; iiiiii<(int)y; iiiiii++) Debug::getInstance()->getDebug() << "  ";\
 	   Debug::getInstance()->getDebug() << x << endl
  #else
    #define DEBUGP(x)
    #define DEBUG2_PRINT(x)
    #define DEBUG2_TABULADO(x,y)
  #endif
  #define DEBUG_COUT(x) Debug::getInstance()->getDebug() << x
  #define DEBUG_PRINT(x) Debug::getInstance()->getDebug() << x << std::endl
  #define DEBUG_TABULADO(x,y)\
    for(int iiiiii=0; iiiiii<(int)y; iiiiii++) Debug::getInstance()->getDebug() << "  ";\
    Debug::getInstance()->getDebug() << x << endl
  #define IFDEBUG(x,y) if(x){ y }
  #define CDEBUG Debug::getInstance()->getDebug()
#else
	/* Para info sobre NDEBUG ver: http://es.wikipedia.org/wiki/Assert.h */
	#define NDEBUG
	#define DEBUGP(x)
  #define DEBUG_COUT(x)
  #define DEBUG_PRINT(x)
  #define DEBUG_TABULADO(x,y)
  #define IFDEBUG(x,y)
  #define DEBUG2_PRINT(x)
  #define DEBUG2_TABULADO(x,y)
#endif

#include <cassert> // Si NDEBUG está definido, los assert se reemplazan por lineas que no hacen nada..

#endif
