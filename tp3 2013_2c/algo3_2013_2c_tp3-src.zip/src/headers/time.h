#ifndef __TIME_H__
/* FUNCIONES PARA MEDIR TIEMPO */
#define __TIME_H__

#ifdef TIME
	#ifdef __clang__
	  #include <sys/timeb.h>
	#else
	  #include <ctime>
	#endif

  typedef struct {
    struct timespec tiempoInicial;
    struct timespec tiempoFinal;
    int64_t tiempoDeEjecucionEnEnSegundos;
    int64_t tiempoDeEjecucionEnNanosegundos;
  } medidor_de_tiempo;

  #define TOMAR_TIEMPO_INICIAL(f)                                       \
  medidor_de_tiempo f;                                                  \
  f.tiempoDeEjecucionEnEnSegundos = 0;                                  \
  f.tiempoDeEjecucionEnNanosegundos = 0;                                \
  clock_gettime( CLOCK_REALTIME, &(f.tiempoInicial) );

  #define TOMAR_TIEMPO_FINAL(f)                                         \
  clock_gettime( CLOCK_REALTIME, &(f.tiempoFinal) );

  #define TOMAR_TIEMPO_IMPRIMIR(f)                                                                            \
  f.tiempoDeEjecucionEnNanosegundos = f.tiempoFinal.tv_nsec - f.tiempoInicial.tv_nsec;                        \
  f.tiempoDeEjecucionEnEnSegundos   = f.tiempoFinal.tv_sec  - f.tiempoInicial.tv_sec;                         \
  parser.tipoTime() << (int64_t) (f.tiempoDeEjecucionEnNanosegundos+ (f.tiempoDeEjecucionEnEnSegundos*1e9) ) << " ns." << std::endl; \


  #define TOMAR_TIEMPO(funcion)               \
  TOMAR_TIEMPO_INICIAL(medidor_de_tiempo)     \
  funcion;                                    \
  TOMAR_TIEMPO_FINAL(medidor_de_tiempo)       \
  TOMAR_TIEMPO_IMPRIMIR(medidor_de_tiempo)    \

#else

  #define TOMAR_TIEMPO(x) (void)x

#endif




#endif
