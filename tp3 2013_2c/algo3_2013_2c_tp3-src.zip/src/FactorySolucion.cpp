#include "FactorySolucion.h"
#include "SolucionBT.h"
#include "SolucionGreedy.h"
#include "SolucionBusquedaLocal.h"
#include "SolucionBusquedaTabu.h"
#include "SelectorPorGrado.h"

FactorySolucion *FactorySolucion::instance = NULL;

FactorySolucion::FactorySolucion()
{
	
}

FactorySolucion::~FactorySolucion()
{

}

Solucion *FactorySolucion::crearSolucion(Grafo &grafo,TipoSolucion tipo_solucion, 
	TipoSolucion tipoSolucionInicial, uint32_t tabuMaxTamanio, uint32_t tabuMaxIteraciones)
{
	Solucion *solucion = NULL;
	switch(tipo_solucion){
		case BACKTRACKING:
			solucion = new SolucionBT(grafo);
			break;
		case GREEDY:
			solucion = new SolucionGreedy(grafo,new SelectorPorGrado(grafo));
			break;
		case BUSQUEDA_LOCAL:
			solucion = new SolucionBusquedaLocal(grafo,tipoSolucionInicial);
			break;
		case BUSQUEDA_TABU:
			solucion = new SolucionBusquedaTabu(grafo,tipoSolucionInicial,tabuMaxTamanio,tabuMaxIteraciones);
			break;
		default:
			break;
	}
	return solucion;
}

