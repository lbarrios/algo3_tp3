#ifndef __SOLUCION_H__
#define __SOLUCION_H__
#include "headers/headers.h"
#include "Grafo.h"
/**
 * Esta clase representa una instancia de solución del problema
 */
class Solucion
{
public:
  Solucion(Grafo&); ///< Constructor
  virtual ~Solucion( void ); ///< Destructor
  uint32_t tamanioFrontera( void ); ///< Indica el tamaño de la frontera de la cliqué
  uint32_t tamanioClique( void ); ///< Indica la cantidad de nodos de la cliqué
  vector<uint32_t> nodosSolucion( void ); ///< Devuelve un vector con los nodos de la clique
  //uint nodo( uint ); ///< Devuelve el ID del "n"-ésimo nodo de la cliqué
  virtual void resolver( void ) = 0; ///< Genera la solución con los parámetros establecidos

protected:
/////////////////////////////////////////////
/// MEJOR SOLUCIÓN
/////////////////////////////////////////////
  /**
   * Set de nodos de la "mejor solución"
   */
  set<uint32_t> _mejorSolucion;
  /**
   * Tamaño de la frontera de la "mejor solución"
   */
  uint32_t _tamanioFronteraMejorSolucion;
  /**
   * Guarda la solución temporal como "mejor solución"
   */
  void _guardarSolucionTemporal( void );

/////////////////////////////////////////////
/// SOLUCIÓN TEMPORAL
/////////////////////////////////////////////	
  /**
   * Set de nodos de la "solución temporal"
   */
  set<uint32_t> _solucionTemporal;
  /**
   * Tamaño de la frontera de la "solución temporal"
   */
  uint32_t _tamanioFronteraSolucionTemporal;
	/**
	 * Conjunto con los nodos adyacentes a la solución temporal.
	 * Se auto-mantiene al usar los métodos
	 * "_solucionTemporalAgregaNodo" y "_solucionTemporalRemueveNodo".
	 * dentro contiene pair<cantidad_de_aristas, nodo_ID>
	 */
	set< pair<uint32_t, uint32_t> > _adyacentesSolucionTemporal;
	/**
	 * Vector de booleanos que indica si un nodo es adyacente a la solución temporal.
	 * Se auto-mantiene al usar los métodos
	 * "_solucionTemporalAgregaNodo" y "_solucionTemporalRemueveNodo".
	 */
	vector<bool> _adyacentesSolucionTemporal_presente;
	/**
	 * Vector de punteros a _adyacentesSolucionTemporal...
	 * Si quiero acceder al nodo=NODO_ID, hago
	 * _adyacentesSolucionTemporal_puntero[NODO_ID]
	 */
	vector< set< pair<uint32_t, uint32_t> >::iterator > _adyacentesSolucionTemporal_puntero;
  /**
   * Agrega un nodo a la solución temporal
   * @param uint ID del nodo
   */
  void _solucionTemporalAgregaNodo( uint32_t );
  /**
   * Quita un nodo de la solución temporal
   * @param uint ID del nodo
   */
  void _solucionTemporalRemueveNodo( uint32_t );
  /**
   * Realiza el output del estado actual de la solución temporal.
   */
  void _imprimeDebugSolucion( void );
  /**
   * Indica si un determinado nodo forma cliqué con la solución temporal.
   * Verifica la adyacencia para todo nodo del set de solución temporal.
   * @param  uint ID del nodo
   * @return bool verdadero si es cliqué
   */
  bool _esCliqueConSolucionTemporal( uint32_t );
/////////////////////////////////////////////
/// Otros
/////////////////////////////////////////////
  /** Grafo original */
  Grafo* _grafo;
};


#include "FactorySolucion.h"
#endif
