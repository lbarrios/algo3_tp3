
#ifndef __SELECTORPORGRADO_H__
#define __SELECTORPORGRADO_H__

#include <vector>

#include "SelectorGreedy.h"

typedef vector< pair<uint32_t,uint32_t> > VectorNodoGrado;  // pair< grado, nodo>

class SelectorPorGrado : public SelectorGreedy {

	public:
		SelectorPorGrado(Grafo &grafo);
		~SelectorPorGrado();
		pair<uint32_t,uint32_t> obtenerMaximoLocal(unsigned int nodo);


	private:
		VectorNodoGrado nodos_por_grado;
		VectorNodoGrado::reverse_iterator proximo;
};



#endif

