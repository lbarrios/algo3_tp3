
#ifndef __SolucionBusquedaLocal_H__
#define __SolucionBusquedaLocal_H__


#include "Solucion.h"

class SolucionBusquedaLocal: public Solucion {
  private:
    void _obtenerPrimerSolucionTemporal();
    void _obtenerMejorSolucionVecinaTemporal();
    FactorySolucion::TipoSolucion _tipoDeSolucionInicial;
	public:
		SolucionBusquedaLocal(Grafo &, FactorySolucion::TipoSolucion);
		~SolucionBusquedaLocal();
		
		void resolver();

};

#endif
