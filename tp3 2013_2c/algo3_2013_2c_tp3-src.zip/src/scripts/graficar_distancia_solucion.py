#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as tck
from glob import glob
from tools import *

from funciones import *

def print_helper(l, k):
    l = ' '.join(sorted(l))
    k = ' '.join(sorted(k))
    print "Soluciones: "+l
    print "Series: "+k
    print
    print "Uso: python grafica_distancia_solucion.py [serie]"


def numero_serie(str):
    " TP3_test2.n_5.out.time.exacta "
    file = str.split("/")[-1]
    n = file.split('.')[1]    # n_5
    return int(n.split('_')[-1])

def solucion(str):
    " TP3_test2.n_5.out.time.exacta "
    return str.split('.')[-1]

def serie_name(str):
    " A B NC2 NC10 "
    name = [s for s in str if s.isalpha()]
    return ''.join(name)

def serie_num(str):
    " A B NC2 NC10 "
    num = [s for s in str if s.isdigit()]
    return ''.join(num)

def indice(sol):
    i = -1
    for s in soluciones:
        i += 1
        if sol == s:
            break
    return i

"""
Grafica el tamaño de frontera para cada una de las soluciones
"""

soluciones = ['exacta', 'golosa', 'local', 'tabu.golosa.sin_optimizar', 'tabu.random.sin_optimizar']

series = {
    "A"  : "tests_tp3.serieA.n4_125",
    "B"  : "tests_tp3.serieB.n100_280",
    "T1" : "tests_tp3.serieT1.n10_150",
    "T2" : "tests_tp3.serieT2.n10_150",
    "U1" : "tests_tp3.serieU1.n10_150",
    "E1" : "tests_tp3.serieE1.n6_100",
    
    "NC2"  : "tests_tp3.serieNC2.n11_100",
    "NC3"  : "tests_tp3.serieNC3.n11_100",
    "NC4"  : "tests_tp3.serieNC4.n12_100",
    "NC5"  : "tests_tp3.serieNC5.n15_100",
    "NC6"  : "tests_tp3.serieNC6.n18_100",
    "NC7"  : "tests_tp3.serieNC7.n21_100",
    "NC8"  : "tests_tp3.serieNC8.n24_100",
    "NC9"  : "tests_tp3.serieNC9.n27_100",
    "NC10" : "tests_tp3.serieNC10.n30_100",
    "NC11" : "tests_tp3.serieNC11.n33_100",
    "NC12" : "tests_tp3.serieNC12.n36_100",
    "NC13" : "tests_tp3.serieNC13.n39_100",
    "NC14" : "tests_tp3.serieNC14.n42_100",
    "NC15" : "tests_tp3.serieNC15.n44_100",
}

print_helper(soluciones, series.keys())
if len(sys.argv) < 2 or sys.argv[1] not in series.keys():
    sys.exit(0)


# data
SERIE = sys.argv[1]
#~ soluciones_elegidas = sys.argv[2:]
soluciones_str = "-".join(soluciones)
x_min = 100000
x_max = -1
x = {}
y = {}

"""
entrada: F k nodos                  # F = #frontera, k = #clique
guardo : F, n
"""
for sol in soluciones:
    print "Procesando solucion", sol
    files = sorted(glob("../test/"+series[SERIE]+"/*.out."+sol), key=numero_serie)
    nodos = []
    data = {}
    for file in files:
        nodo = numero_serie(file)
        if nodo not in nodos:
            nodos.append(nodo)
            data[nodo] = []
        with open(file, 'r') as f:
            frontera = f.readline().split()[0]
            data[nodo].append(int(frontera))
    if len(nodos) > 0:
        x_min = nodos[0] if nodos[0] < x_min else x_min
        x_max = nodos[-1] if nodos[-1] > x_max else x_max
        x[sol] = np.array(nodos)
        y[sol] = np.array([np.average(data[nodo]) for nodo in nodos])
x['teo'] = np.arange(x_min, x_max+1, 5)


### Ploteo ###

# - Creo los subplot
fig, (sp) = plt.subplots(nrows=1, ncols=1, sharex=True, sharey=False)
TITULO = "Distancia entre soluciones \n [serie "+SERIE+"]"

#~ formatter = tck.EngFormatter(unit='s', places=1) # Formato "segundos"
#~ formatter.ENG_PREFIXES[-6] = 'u' # Arreglo el símbolo "mu"
#~ sp.yaxis.set_major_formatter(formatter) # Aplico formato
sp.set_title(TITULO)
sp.set_xlabel('nodos')
sp.set_ylabel('frontera')

# exacta, golosa, local, tabu.golosa.sin_optimizar, tabu.random.sin_optimizar
for s in sorted(x.keys(), key=indice):
    if s == "exacta":
        sp.plot(x[s], y[s], '-', color='red', linewidth=4, label='solucion '+s)
    elif s == "golosa":
        sp.plot(x[s], y[s], 's', color='blue', linewidth=1, label='solucion '+s)
    elif s == "local":
        sp.plot(x[s], y[s], '^', color='#F0D720', linewidth=1, label='solucion '+s)
    elif s == "tabu.golosa.sin_optimizar":
        sp.plot(x[s], y[s], '3', color='#1F9524', linewidth=1, label='solucion '+s)
    elif s == "tabu.random.sin_optimizar":
        sp.plot(x[s], y[s], '4', color='#BA1853', linewidth=1, label='solucion '+s)


sp.legend(loc=2)

if not os.path.exists('../graficos/') or not os.path.isdir('../graficos/'):
    os.makedirs('../graficos/')
plt.savefig("../graficos/frontera_serie"+SERIE+".eps")
plt.show()


