#!/bin/bash

# levanta una serie de tests, los corre
# y guarda el resultado en el mismo dir con el formato
# NOMBRE_ORIGINA_SIN_IN.out.time.TIPO_SOLUCION
# ejemplo:
# entrada: ../test/tests_tp3.serieA.n4_125/TP3_test2.n_5.in
# salida : ../test/tests_tp3.serieA.n4_125/TP3_test2.n_5.out[.time].exacta

USO="Uso : sh ejecutar_serie.sh [serie A|B|..] [solucion exacta|golosa|local|tabu] [.time (opcional)]"
if [ $# -lt 2 ]; then
    echo $USO
    exit
fi

case "$1" in

    "A")  SERIE="tests_tp3.serieA.n4_125"
        ;;
    "B")  SERIE="tests_tp3.serieB.n100_280"
        ;;
    "T1") SERIE="tests_tp3.serieT1.n10_150"
        ;;
    "T2") SERIE="tests_tp3.serieT2.n10_150"
        ;;
    "U1") SERIE="tests_tp3.serieU1.n10_150"
       ;;
      *)  SERIE="--error_serie--"
       ;;
esac

SOLUCION=$2
TIME=$3
DIR=test/$SERIE
INFILES=../$DIR/TP3_test*.n_*.in

# run
echo "[[ Serie $1 ($SERIE) $SOLUCION $TIME ]]"
for input in $INFILES; do
    FILENAME=$(basename "$input")
    TEST="${FILENAME%.*}"
    OUTFILE="../$DIR/$TEST.out.$SOLUCION"
    OUTFILETIME="../$DIR/$TEST.out$TIME.$SOLUCION"
    echo "Procesando $TEST $TIME"
    if [ -z "$TIME" ]; then
        ../tp3 -i ${input} -o ${OUTFILE} -s ${SOLUCION}
    else
        i=1
        ../tp3${TIME} -i ${input} -o ${OUTFILE} -s ${SOLUCION} -t tmp.txt
        while read line
        do
            array[$i]="$line"
            (( i++ ))
        done < tmp.txt
        # formato de salida: time \n data
        echo ${array[1]} > ${OUTFILETIME}
        echo ${array[2]} > ${OUTFILE}
        rm tmp.txt
    fi
done
