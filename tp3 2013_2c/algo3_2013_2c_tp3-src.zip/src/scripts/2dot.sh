#!/bin/bash -x

file=$1

rm -f ${file}.dot
rm -f ${file}.png

echo "graph output {" >> ${file}.dot
size=$( cat  $file | wc -l )
cat $file | tail -$(( size -1)) | head -$((size -2))  | awk '{ print $1" -- "$2}' >> ${file}.dot
echo "}" >> ${file}.dot

dot -Tpng -o ${file}.png ${file}.dot

