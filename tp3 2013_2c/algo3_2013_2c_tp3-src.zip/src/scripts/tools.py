#!/usr/bin/env python
# -*- coding: utf-8 -*-

def rango_nodos(str):
  """
  input: tests_tp3.serieA1.n4_20
  output: 4, 20
  input: tests_tp3.serieA2.n25_125
  output: 25, 125
  """
  nodos = str.split('.')[-1]
  nodos = nodos.split('_')
  ni = int(nodos[0][1:])
  nj = int(nodos[1])
  return ni, nj
  
def nodotest(str):
  """
  input: ../TP3_test11.n_14.out
  input: ../TP3_test11.n_14.MY.exacta.out
  output: 14
  """
  str = str.split('/')[-1]
  num = str.split('.')[1]
  return int(num.split('_')[-1])

def cardinal(file):
  """ El cardinal de la frontera es el primer valor de la primera linea del archivo de salida """
  with open(file) as f:
    first_line = f.readline()
  return first_line.split()[0]

def vector_nodos(filelist):
  list = []
  for file in filelist:
    n = nodotest(file)
    list.append(n)
  return list

def vector_fronteras(filelist):
  list = []
  for file in filelist:
    F = cardinal(file)
    list.append(int(F))
  return list
