#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import numpy as np
import scipy.misc as sc
import matplotlib.pyplot as plt
import matplotlib.ticker as tck
from glob import glob

from funciones import *

def print_helper(l, k):
    l = ' '.join(sorted(l))
    k = ' '.join(sorted(k))
    print "Soluciones: "+l
    print "Series: "+k
    print
    print "Uso: python grafica_tiempo.py [solucion] [series]"


def numero_serie(str):
    " TP3_test2.n_5.out.time.exacta "
    file = str.split("/")[-1]
    n = file.split('.')[1]    # n_5
    return int(n.split('_')[-1])

def solucion(str):
    " TP3_test2.n_5.out.time.exacta "
    return str.split('.')[-1]

def serie_name(str):
    " A B NC2 NC10 "
    name = [s for s in str if s.isalpha()]
    return ''.join(name)

def serie_num(str):
    " A B NC2 NC10 "
    num = [s for s in str if s.isdigit()]
    return ''.join(num)

"""
Grafica los promedios de tiempos/llamadas recursivas para cada outputs/random/output.time.n*

entrada : ../test/tests_tp3.serieA.n4_125/TP3_test2.n_5.out.time.exacta
"""

soluciones = [
'exacta',
'golosa',
'local',
'tabu',
'tabu.golosa.sin_optimizar',
'tabu.random.sin_optimizar',
'tabu.golosa.log_n_2.parametros',
'tabu.golosa.logn.parametros',
'tabu.golosa.mitad_n.parametros',
'tabu.golosa.n.parametros',
'tabu.golosa.tercio_n.parametros'
]

series = {
    "A"  : "tests_tp3.serieA.n4_125",
    "B"  : "tests_tp3.serieB.n100_280",
    "T1" : "tests_tp3.serieT1.n10_150",
    "T2" : "tests_tp3.serieT2.n10_150",
    "U1" : "tests_tp3.serieU1.n10_150",
    "E1" : "tests_tp3.serieE1.n6_100",
    
    "NC2"  : "tests_tp3.serieNC2.n11_100",
    "NC3"  : "tests_tp3.serieNC3.n11_100",
    "NC4"  : "tests_tp3.serieNC4.n12_100",
    "NC5"  : "tests_tp3.serieNC5.n15_100",
    "NC6"  : "tests_tp3.serieNC6.n18_100",
    "NC7"  : "tests_tp3.serieNC7.n21_100",
    "NC8"  : "tests_tp3.serieNC8.n24_100",
    "NC9"  : "tests_tp3.serieNC9.n27_100",
    "NC10" : "tests_tp3.serieNC10.n30_100",
    "NC11" : "tests_tp3.serieNC11.n33_100",
    "NC12" : "tests_tp3.serieNC12.n36_100",
    "NC13" : "tests_tp3.serieNC13.n39_100",
    "NC14" : "tests_tp3.serieNC14.n42_100",
    "NC15" : "tests_tp3.serieNC15.n44_100",
}



print_helper(soluciones, series.keys())
if len(sys.argv) < 2 or sys.argv[1] not in soluciones:
    sys.exit(0)


# data
SOL = sys.argv[1]
series_elegidas = sys.argv[2:]
elegidas_str = "-".join(series_elegidas)
x_min = 100000
x_max = -1
x = {}
y = {}
for serie in series_elegidas:
    if serie not in series.keys():
        continue
    print "Procesando serie", serie
    files = sorted(glob("../test/"+series[serie]+"/*.out.time."+SOL), key=numero_serie)
    if not files:
        print "No estan los archivo buscados en ../test/"+series[serie]+"/*.out.time."+SOL
        break
    nodos = []
    data = {}
    for file in files:
        nodo = numero_serie(file)
        if nodo not in nodos:
            nodos.append(nodo)
            data[nodo] = []
        with open(file, 'r') as f:
            tiempo = f.readline().split()[0]
            try:
                data[nodo].append(int(tiempo))
            except:
                pass
    if len(nodos) > 0:
        x_min = nodos[0] if nodos[0] < x_min else x_min
        x_max = nodos[-1] if nodos[-1] > x_max else x_max
        x[serie] = np.array(nodos)
        y[serie] = np.array([np.average(data[nodo]) for nodo in nodos])
x['teo'] = np.arange(x_min, x_max, 5)


### Ploteo ###

# - Creo los subplot
fig, (spTiempo) = plt.subplots(nrows=1, ncols=1, sharex=True, sharey=False)
TITULO = "Tiempos de ejecucion \n [solucion "+SOL+", series "+elegidas_str+"]"

formatter = tck.EngFormatter(unit='s', places=1) # Formato "segundos"
formatter.ENG_PREFIXES[-6] = 'u' # Arreglo el símbolo "mu"
spTiempo.yaxis.set_major_formatter(formatter) # Aplico formato
spTiempo.set_title(TITULO)
spTiempo.set_xlabel('nodos')
spTiempo.set_ylabel('tiempo')

for serie in x.keys():
    if serie == "A":
        spTiempo.plot(x[serie], y[serie], '-',  color='red', linewidth=1, label="serie "+serie)
    elif serie == "B":
        spTiempo.plot(x[serie], y[serie], '-',  color='blue', linewidth=1, label="serie "+serie)
    elif serie == "T1":
        spTiempo.plot(x[serie], y[serie], '-*',  color='green', linewidth=1, label="serie "+serie)
    elif serie == "T2":
        spTiempo.plot(x[serie], y[serie], '-^',  color='magenta', linewidth=1, label="serie "+serie)
    elif serie == "U1":
        spTiempo.plot(x[serie], y[serie], '-',  color='grey', linewidth=1, label="serie "+serie)
    elif serie == "E1":
        spTiempo.plot(x[serie], y[serie], '-',  color='magenta', linewidth=1, label="serie "+serie)
    elif serie_name(serie) == "NC":
        spTiempo.plot(x[serie], y[serie], '-' , linewidth=1, label="serie "+serie)

#~ spTiempo.plot(x['teo'], np.power(x['teo'],4)*8, '--', color='black', linewidth=2, label="4^n") # exponencial
spTiempo.plot(x['teo'], 1500*(x['teo']**2), '--', color='black', linewidth=2, label="n^2") # cuadratica
#~ spTiempo.plot(x['teo'], 4000*(x['teo']**2)*np.log(x['teo']), '--', color='black', linewidth=2, label="k*n^2*ln(n)") # n^2 * log n
#~ spTiempo.plot(x['teo'], 10*(x['teo'])*(np.log(x['teo'])), '--', color='black', linewidth=2, label="n*ln(n)") # n * log n
#~ spTiempo.plot(x['teo'], 800*x['teo'], '--', color='black', linewidth=2, label="k*n") # lineal
spTiempo.legend(loc=2)

if not os.path.exists('../graficos/') or not os.path.isdir('../graficos/'):
    os.makedirs('../graficos/')
plt.savefig("../graficos/tiempo_"+SOL+"_series"+elegidas_str+".eps")
plt.show()
