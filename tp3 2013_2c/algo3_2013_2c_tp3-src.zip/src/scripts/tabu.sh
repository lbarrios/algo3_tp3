#!/bin/bash

  rm plot.txt
  for i in $( ls test/tests_tp3.serieB.n100_280/*.in | sort | xargs )
  do
    name=$(echo $i | cut -d"/" -f3)
    nodos=$( head -1 $i | cut -d" " -f1)
    test=$( echo $name | cut -d"/" -f4 | cut -d"." -f1 | cut -d"_" -f3 )
    tabu_size=$(( $nodos * 5))
    echo "# Test $test - Nodos: $nodos" >> plot.txt
    cat /tmp/debug/${name}.debug.${tabu_size} | grep "Frontera " | head -1000 | awk 'BEGIN {sum=0} {sum+=1;print sum" "$2}' >> plot.txt
    echo "" >> plot.txt
    echo "" >> plot.txt
  done
