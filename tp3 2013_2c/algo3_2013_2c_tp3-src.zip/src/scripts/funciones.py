# -*- coding: utf-8 -*-

import sys
import numpy as np
import numpy.random as random
from kruskal import kruskal




"""
Familias de Grafos
"""

def dist_uniforme(n, aristas):
    """
    Para el grafo con n nodos, la cantidad de aristas se determina mediante
    la distribucion uniforme (randint) entre [a,b] = [ (n*(n-1)/2)/4, n*(n-1)/2 ]
    (por lo menos un cuarto de aristas y a lo sumo el grafo completo)
    """
    max_m = (n*(n-1))/2
    m = random.randint((max_m)/4, max_m)
    aristas_agregadas = []
    aristas_posibles  = aristas.tolist()
    while m > 0:
        pos = random.randint(0, len(aristas_posibles))
        e = aristas_posibles[pos]
        mover_arista(n, e, aristas_posibles, aristas_agregadas)
        m -= 1
    return aristas_agregadas



def startree(n, aristas):
    return tree(n, aristas, "star")

def randtree(n, aristas):
    return tree(n, aristas, "random")


"""
Segun el peso que se le de al edge, es el árbol que quedará.
Si se asigna a todas el mismo peso, el orden de kruskal genera un árbol estrella.
"""
def tree(n, aristas, familia = "star"):
    vertices = []
    edges    = []
    for e in np.nditer(aristas):
        peso = {
            "star": 0,
            "random": random.randint(n**3)
        }
        v1, v2 = nodos(e,n)
        if v1 not in vertices:
            vertices.append(v1)
        if v2 not in vertices:
            vertices.append(v2)
        edges.append( (peso[familia], v1, v2) )
    graph = {
        'vertices': vertices,
        'edges': set(edges)
    }
    aristas = []
    for i in kruskal(graph):
        aristas.append( str(i[1])+" "+str(i[2]) )
    return aristas






def mover_arista(n, e, posibles, agregadas):
    """
    Toma la arista e, la inserta en agregadas y la quita de posibles.
    La lista de posible contiene enteros entre [2,3,...n-1,n+1,..(n**2)-1] que representan
    una posicion (fila, columna) de una matriz donde (fila,columna) representan pares de nodos.
    """
    v1, v2 = nodos(e,n)
    agregadas.append(str(v1)+" "+str(v2))
    posibles.remove(e)

def nodos(e,n):
    v1 = (e / n) + 1
    v2 = (e % n) + 1
    return v1, v2
