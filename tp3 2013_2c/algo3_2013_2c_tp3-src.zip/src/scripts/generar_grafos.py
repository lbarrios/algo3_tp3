#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import numpy as np
import numpy.random as random
from glob import glob
from tools import *

import pdb
from funciones import *


def print_helper(dist):
    str = '|'.join(sorted(dist.keys()))
    print "--Error de ejecución--"
    print "Uso: python gen-graphs.py ["+str+"|...] [n-inicial] [n-final]\n"
    for i in sorted(dist.keys()):
        print i+" =", dist[i].__name__
    sys.exit(0)

def folder(name, i, j):
    # tests_tp3.serie{name}.n{i}_{j}/
    return "tests_tp3.serie" + name + ".n" + str(i) + "_" + str(j) + "/"

# --



distribuciones = {
    'U1': dist_uniforme,
    'T1': randtree,
    'T2': startree
} ### agregar funciones generadoras de distribucion de familias aqui

# chequeo de condiciones
if len(sys.argv) < 4:
    print_helper(distribuciones)

familia = sys.argv[1]
ni = int(sys.argv[2])
nj = int(sys.argv[3])

if familia not in distribuciones.keys() or ni > nj or ni < 0 or nj < 0:
    print_helper()



"""
Grafica la distancia entre cada tipo de solucion heuristica y la solucion exacta
"""
BASEPATH = '../test/'
SERIEPATH = folder(familia, ni, nj)
FULLPATH = BASEPATH+SERIEPATH

if not os.path.exists(FULLPATH) or not os.path.isdir(FULLPATH):
    os.makedirs(FULLPATH)

print "[Generando Serie "+familia+" con grafos de "+str(ni)+".."+str(nj)+" nodos]"

# Formato de entrada (o sea, de salida)
"""
TP3_test2.n_5.in
5 6
1 2
1 3
1 4
1 5
4 5
3 5
0
"""

CANT_N = 1
i = 1 # test number
for n in range(ni, nj+1):
    # genero todas aristas como un lista que representa una matriz
    aristas = np.arange(n**2)
    aristas = aristas[ aristas/n > aristas%n ]
    # genero los grafos
    for k in range(CANT_N):
        # distribucion generada segun la familia elegida
        aristas_agregadas = distribuciones[familia](n, aristas)
        m = len(aristas_agregadas)
        
        # vuelco data en el grafo
        filename = "TP3_test"+str(i)+".n_"+str(n)+".in"
        input = str(n) + " " + str(m) + "\n"    # n m
        for e in aristas_agregadas:
            input += e + "\n"                   # v w
        print "Generando", filename
        input += "0"
        f = open(FULLPATH+filename, 'w')
        f.write(input)
        f.close()
        i += 1
