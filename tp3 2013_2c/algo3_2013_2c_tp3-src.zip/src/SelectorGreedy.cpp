
#include "SelectorGreedy.h"

SelectorGreedy::SelectorGreedy(Grafo &grafo)
	:grafo(grafo)
{
	

}

SelectorGreedy::~SelectorGreedy(){

}



void SelectorGreedy::actualizarValores(unsigned int nodo){

}


