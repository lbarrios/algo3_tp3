
#ifndef __SOLUCIONBUSQUEDATABU_H__
#define __SOLUCIONBUSQUEDATABU_H__

#include <vector>
#include <set>

#include "Solucion.h"
#include "FactorySolucion.h"

using namespace std;

typedef set <uint32_t> SetNodos;
typedef vector <uint32_t> VectorNodos;
typedef vector < SetNodos > ListaTabu;


class SolucionBusquedaTabu: public Solucion {

	public:
		SolucionBusquedaTabu(Grafo &grafo, FactorySolucion::TipoSolucion tipo_solucion_inicial = FactorySolucion::GREEDY,int max_tabu_size = 0,int max_itr = 0 );
		~SolucionBusquedaTabu();
		
		void resolver();

	private:
		bool mejoroSolucionVecindad(int &mejor_frontera_vecindad,int &mejor_tabu_vecindad);
		enum Operacion {ADD,DEL,SWAP};
		void obtenerSolucionInicial();
		int obtenerMejorSolucionVecindad();
		void agregarAListaTabu();
		void proximaPosicionTabu();
		int esTabu();


		int max_itr;
		int max_tabu_size;
		ListaTabu lista_tabu; 
		ListaTabu::iterator tabu_itr;
		FactorySolucion::TipoSolucion tipo_solucion_inicial;
		int solucion_temporal_tabu_rank;
		uint32_t tamanio_frontera_anterior;
		int iteracion_global;
		int iteracion_ms;
		int tamanio_tabu;
		bool no_loop;
		
};

#endif
