
#ifndef __SELECTOR_GREEDY_H__
#define __SELECTOR_GREEDY_H__

#include <utility>

#include "Grafo.h"


class SelectorGreedy{
	public:
		SelectorGreedy(Grafo &grafo);
		virtual ~SelectorGreedy();

		/**
		 * Devuelve par <peso,nodo> con peso maximo del selector
		 */
		virtual pair<uint32_t,uint32_t> obtenerMaximoLocal(uint32_t nodo) = 0;
		/** 
		 * Los selectores que requieran actualizar valores 
		 * de de la estructura del selector al agregar un nodo a la solucion,
		 * tienen que sobrecargar este miembro. Por defecto
		 * no se actualiza nada.
		 */
		virtual void actualizarValores(uint32_t nodo);
	protected:
		Grafo &grafo;

};

#endif

