
#include "SolucionGreedy.h"

SolucionGreedy::SolucionGreedy( Grafo &grafo, SelectorGreedy *selector)
	:Solucion(grafo)
{
	this->selector = selector;
	this->ultimo_nodo = 0;
	DEBUG_PRINT("Resolviendo solucion hambrienta");
}

SolucionGreedy::~SolucionGreedy(){

	delete selector;
}


void SolucionGreedy::resolver(){
	pair<int,int> peso_nodo(0,0);
	
	
	while( true ) {
		
		peso_nodo = selector->obtenerMaximoLocal(ultimo_nodo);
		if( peso_nodo.first == 0 )
			break;

		if( _esCliqueConSolucionTemporal(peso_nodo.second) ){
			_solucionTemporalAgregaNodo(peso_nodo.second);	
			if( _tamanioFronteraSolucionTemporal > _tamanioFronteraMejorSolucion ){
				_guardarSolucionTemporal();
				ultimo_nodo = peso_nodo.second;
			}else{
				_solucionTemporalRemueveNodo(peso_nodo.second);
				
			}
		}
			
	}
	_guardarSolucionTemporal();
}

