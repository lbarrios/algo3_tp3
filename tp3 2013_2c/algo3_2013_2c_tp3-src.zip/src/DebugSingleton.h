#ifndef __DEBUG_SINGLETON_H__
#define __DEBUG_SINGLETON_H__
#include "headers/headers.h"

/*Singleton Debug*/
class Debug{
public:
	
	/* Inicializa única instancia de Debug */
	static void init( ostream& debug ){
		instance = new Debug( debug );
	};
	/** Elimina instancia de Debug 
	 * Pre: haber inicializado singleton con metodo statico init() 
     */
	static void end(){
		if(instance){
			delete instance;
			instance = NULL;
		}
	};
	/** Devuelve instancia de singleton Debug
	 * Pre: haber inicializado singleton con metodo statico init() 
     */
	static Debug *getInstance(){
		return instance;
	};

	/**
	 * Devuelve un puntero a debug...
	 */
	ostream &getDebug(void){
		return _debug;
	}

protected:
	static Debug *instance;
	ostream &_debug;
private:
	Debug( ostream& _debug );
	~Debug();
};

#endif
