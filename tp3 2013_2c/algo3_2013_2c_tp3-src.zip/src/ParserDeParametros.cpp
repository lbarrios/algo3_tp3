#include "ParserDeParametros.h"

#define LINEA_PUNTEADA "--------------------------------------------------------------------------------"
#define TITULO_ERROR LINEA_PUNTEADA << endl << "----------------------------------   ERROR   -----------------------------------" << endl << LINEA_PUNTEADA << endl
#define TITULO_AYUDA LINEA_PUNTEADA << endl << "----------------------------------   AYUDA   -----------------------------------" << endl << LINEA_PUNTEADA << endl

#define STRING_EXACTA "exacta"
#define STRING_GOLOSA "golosa"
#define STRING_LOCAL "local"
#define STRING_TABU "tabu"

#define STRING_INICIAL_GOLOSA "golosa"
#define STRING_INICIAL_RANDOM "random"

#define OPT_TABU_SIZE "tabu_max_tamanio"
#define OPT_TABU_ITER "tabu_max_iteraciones"
#define OPT_INICIAL_S "solucion_inicial"


ParserDeParametros::ParserDeParametros(int argc, char** argv){
  if ( argc < 1 ) exit(EXIT_FAILURE);
  _nombrePrograma = argv[0];
  _input=NULL, _output=NULL, _debug=NULL, _time=NULL, _tabu_max_tamanio=0, _tabu_max_iteraciones=0, _tipoDeSolucionInicial=-1;
  int tipoDeSolucion=-1;
  static struct option l_opts[] = {
    {"input",            required_argument,    NULL,   'i' },
    {"output",           required_argument,    NULL,   'o' },
    {"solucion",         required_argument,    NULL,   's' },
    {"debug",            required_argument,    NULL,   'd' },
    {"time",             required_argument,    NULL,   't' },
    {OPT_TABU_SIZE,      required_argument,    NULL,    0  },
    {OPT_TABU_ITER,      required_argument,    NULL,    0  },
    {OPT_INICIAL_S,      required_argument,    NULL,    0  },
    {"help",             no_argument,          NULL,   'h' },
    {NULL,               0,                    NULL,    0  }
  };
  //-max_itr <numero> -max_tabu_size <numero> -si <GREEDY|RANDOM>
  int opt=0, long_opt;
  opterr=0; //< Deshabilito el manejo de errores por defecto.
  while ( (opt=getopt_long(argc, argv,"i:o:s:d:t:h", l_opts, &long_opt )) !=-1 ) {
    switch (opt) {
      case 0 :
        if(!strcmp(l_opts[long_opt].name, OPT_TABU_SIZE)){
          this->_tabu_max_tamanio = atoi(optarg);
          if(this->_tabu_max_tamanio > 0){
            break;
          }
        }
        if(!strcmp(l_opts[long_opt].name, OPT_TABU_ITER)){
          this->_tabu_max_iteraciones = atoi(optarg);
          if(this->_tabu_max_iteraciones > 0){
            break;
          }
        }
        if(!strcmp(l_opts[long_opt].name, OPT_INICIAL_S)){
          if (!strcmp(optarg,STRING_INICIAL_GOLOSA)){
            _tipoDeSolucionInicial=FactorySolucion::GREEDY;
            break;
          }
          if (!strcmp(optarg,STRING_INICIAL_RANDOM)){
            _tipoDeSolucionInicial=FactorySolucion::NODO_RANDOM;
            break;
          }
        }
        _imprimirErrorParametro( l_opts[long_opt].name, optarg );
        break;
      case 'i' : //< --input
        if( strcmp(optarg,"stdin") ){
          _finput.open( optarg, fstream::in );
          if( !_finput ) _imprimirErrorInput( optarg );
          else _input = (istream*) &_finput;
        } else _input = (istream*) &cin;
        break;
      case 'o' : //< --output
        if( strcmp(optarg,"stdout") ) {
          _foutput.open( optarg, fstream::out );
          if( !_foutput ) _imprimirErrorOutput( optarg );
          else _output = (ostream*) &_foutput;
        } else _output = (ostream*) &cout;
        break;
      case 's' : //< --solucion
        if( !strcmp(optarg,STRING_EXACTA) ){
          _tipoDeSolucion=FactorySolucion::BACKTRACKING;
          tipoDeSolucion = 1;
          break;
        }
        if( !strcmp(optarg,STRING_GOLOSA) ){
          _tipoDeSolucion=FactorySolucion::GREEDY;
          tipoDeSolucion = 1;
          break;
        }
        if( !strcmp(optarg,STRING_LOCAL)){
          _tipoDeSolucion=FactorySolucion::BUSQUEDA_LOCAL;
          tipoDeSolucion = 1;
          break;
        }
        if( !strcmp(optarg,STRING_TABU)){
          _tipoDeSolucion=FactorySolucion::BUSQUEDA_TABU;
          tipoDeSolucion = 1;
          break;
        }
        _imprimirErrorSolucion( optarg );
        break;
      case 'd' : //< --debug
        #ifndef DEBUG
          _imprimirErrorDebug( optarg );
        #else
          if( strcmp(optarg,"stderr") ) {
            _fdebug.open( optarg, fstream::out );
            if( !_fdebug ) _imprimirErrorDebug( optarg );
            else _debug = (ostream*) &_fdebug;
          } else _debug = (ostream*) &cerr;
        #endif
        break;
      case 't' : //< --time
        #ifndef TIME
          _imprimirErrorTime( optarg );
        #else
          if( strcmp(optarg,"stderr") && strcmp(optarg, "stdout") )
          {
            _ftime.open( optarg, fstream::out );
            if( !_ftime )
            {
            	_imprimirErrorTime( optarg );
            }
            else
            {
            	_time = (ostream*) &_ftime;
            }
          }
          else
          {
          	if( strcmp(optarg,"stderr") )
          	{
          	  _time = (ostream*) &cout;
          	}
          	else
          	{
          	  _time = (ostream*) &cerr;
          	}
          }
        #endif
        break;
      case 'h' : //< --help
        _imprimirAyuda(); 
        exit(EXIT_SUCCESS); 
        break;
      case '?' : //< ¡¡Opción no reconocida!!
        if(argc <= optind)
          cerr << "No se reconoce la opción " << argv[argc-1] << "." << endl;
        else
          cerr << "No se reconoce la opción " << argv[optind] << "." << endl;
      default : 
        _imprimirAyudaError(); 
    }
  }

  // Me fijo si el input es válido.
  if(!_input)
    cerr << "Error: No se ha indicado el input (-i [stdin|RUTA_ARCHIVO])" << endl;
  // Me fijo si el output es válido.
  if(!_output)
    cerr << "Error: No se ha indicado el output (-o [stdout|RUTA_ARCHIVO])" << endl;
  #ifdef DEBUG
  if(!_debug)
    cerr << "Error: No se ha indicado el debug (-d [stderr|RUTA_ARCHIVO])" << endl;
  #endif
  #ifdef TIME
  if(!_time)
  	cerr << "Error: No se ha indicado el output de time (-t [stdout|stderr|RUTA_ARCHIVO)" << endl;
  #endif
  // Me fijo si el tipo de solución es válido
  if(!++tipoDeSolucion)
    cerr << "Error: No se ha indicado el tipo de solución (-s [exacta|golosa|local|tabu])" << endl;
  // Me fijo si el tipo de solución inicial es válido
  if(_tipoDeSolucionInicial!=-1){
    if (!(_tipoDeSolucion==FactorySolucion::BUSQUEDA_LOCAL || _tipoDeSolucion==FactorySolucion::BUSQUEDA_TABU)){
      cerr << "Error: El parámetro --" << OPT_INICIAL_S << " solamente puede ser" << endl << 
      "aplicado a las soluciones " << STRING_LOCAL << " y " << STRING_TABU << "." << endl;
      tipoDeSolucion = false;
    }
  }
  /**
   * Analizo los parámetros, si hay errores detengo la ejecución
   */
#ifdef DEBUG
  if(!_input || !_output || !tipoDeSolucion || !_debug)
#else
  #ifdef TIME
    if(!_input || !_output || !tipoDeSolucion || !_time)
  #else
    if(!_input || !_output || !tipoDeSolucion)
  #endif
#endif
    _imprimirAyudaError();
}
ParserDeParametros::~ParserDeParametros( void ){
  /* Destructor */
}
void ParserDeParametros::_imprimirAyudaError( void ){
#ifdef DEBUG
  cerr << "Uso: Ejecute " << endl <<
    "\t" << _nombrePrograma << " -i INPUT -o OUPUT -s SOLUCION -d DEBUG" << endl;
#else
	#ifdef TIME
 		cerr << "Uso: Ejecute " << endl <<
	    "\t" << _nombrePrograma << " -i INPUT -o OUPUT -s SOLUCION -t TIME" << endl;
	#else
 		cerr << "Uso: Ejecute " << endl <<
	    "\t" << _nombrePrograma << " -i INPUT -o OUPUT -s SOLUCION" << endl;
  #endif
#endif
  cerr << "Ejecute el parámetro [-h | --help] si desea obtener ayuda" << endl;
  exit(EXIT_FAILURE);
}
void ParserDeParametros::_imprimirAyuda( void ){
  cout << TITULO_AYUDA << endl;

  cout << "Para correr este programa debe respetar la siguiente sintaxis:" << endl;
  #ifdef DEBUG
  cout << _nombrePrograma << " --input=INPUT --output=OUTPUT --debug=DEBUG --solucion=SOLUCION" << endl;
  #else
  	#ifdef TIME
  	cout << _nombrePrograma << " --input=INPUT --output=OUTPUT --time=TIME --solucion=SOLUCION" << endl;
  	#else
  	cout << _nombrePrograma << " --input=INPUT --output=OUTPUT --solucion=SOLUCION" << endl;
  	#endif
  #endif
  cout << "\t" << "•) INPUT = [stdin|RUTA_ARCHIVO]" << endl
           << "\t\t" << "utilizar entrada estándar ó un archivo" << endl
       << "\t" << "•) OUTPUT = [stdout|RUTA_ARCHIVO]" << endl
           << "\t\t" << "utilizar salida estándar ó un archivo" << endl
    #ifdef DEBUG
       << "\t" << "•) DEBUG = [stderr|RUTA_ARCHIVO]" << endl
           << "\t\t" << "utilizar salida error ó un archivo" << endl
    #endif
    #ifdef TIME
       << "\t" << "•) TIME = [stdout|stderr|RUTA_ARCHIVO]" << endl
           << "\t\t" << "utilizar salida estándar, error ó un archivo" << endl
    #endif
       << "\t" << "•) SOLUCION = TIPO_DE_SOLUCION. Soluciones implementadas:" << endl
           << "\t\t" << STRING_EXACTA << ": Algoritmo de BT (diente azul \"in inglish\")." << endl
           << "\t\t" << STRING_GOLOSA << ": Algoritmo heurístico hambriento." << endl
           << "\t\t" << STRING_LOCAL  << ": Algoritmo de búsqueda local." << endl
           << "\t\t" << STRING_TABU   << ": Algoritmo de búsqueda tabú." << endl;
  cout << endl
  << "Parámetros extra:" << endl
  << "\t" << "•) --" << OPT_TABU_SIZE << "=K" << endl
  << "\t\t" << "Tamaño máximo (K>0) para la tabú." << endl
  << "\t" << "•) --" << OPT_TABU_ITER << "=K" << endl
  << "\t\t" << "Cantidad máxima de iteraciones (K>0) para la tabú." << endl
  << "\t" << "•) --" << OPT_INICIAL_S << " = ["<<STRING_INICIAL_GOLOSA<<","<<STRING_INICIAL_RANDOM<<"]" << endl
  << "\t\t" << "Solución inicial (para tabú y local)." << endl;

  cout << endl << "Se pueden reemplazar todos los parámetros no opcionales de la forma" << endl
       << "\"--parametro=VALOR\" por su versión corta \"-p VALOR\", ejemplo:" << endl
       #ifdef DEBUG
       << "\t" << _nombrePrograma << " -i stdin -o stdout -d stderr -s exacta" << endl;
       #else
       	#ifdef TIME
       	<< "\t" << _nombrePrograma << " -i stdin -o stdout -t stderr -s exacta" << endl;
       	#else
       	<< "\t" << _nombrePrograma << " -i stdin -o stdout -s exacta" << endl;
       	#endif
       #endif
  cout << endl << LINEA_PUNTEADA << endl;
}
void ParserDeParametros::_imprimirErrorInput( string nombreArchivo ){
  cerr << TITULO_ERROR <<
"No se puede abrir el archivo de input indicado ("<< nombreArchivo <<")." 
  << endl;
  exit(EXIT_FAILURE);
}
void ParserDeParametros::_imprimirErrorOutput( string nombreArchivo ){
  cerr << TITULO_ERROR <<
"No se puede abrir el archivo de output indicado ("<< nombreArchivo <<")." 
  << endl;
  exit(EXIT_FAILURE);
}
void ParserDeParametros::_imprimirErrorSolucion( string tipoDeSolucion ){
  cerr << TITULO_ERROR <<
"No se reconoce el tipo de solución indicada: " << tipoDeSolucion <<"."
  << endl;
  exit(EXIT_FAILURE);
}
void ParserDeParametros::_imprimirErrorDebug( string nombreArchivo ){
#ifndef DEBUG
  cerr << TITULO_ERROR <<
  "Para realizar debug debe correr el ejecutable para debug." << endl <<
  "Probablemente ud. desee correr " << _nombrePrograma << ".debug" <<
  " o " << _nombrePrograma << ".debug2"
  << endl;
#else
  cerr << TITULO_ERROR <<
  "No se puede abrir el archivo de debug indicado ("<< nombreArchivo <<")." 
  << endl;
#endif
  exit(EXIT_FAILURE);
}
void ParserDeParametros::_imprimirErrorTime( string nombreArchivo ){
#ifndef DEBUG
  cerr << TITULO_ERROR <<
  "Para medir tiempo debe correr el ejecutable correcto." << endl <<
  "Probablemente ud. desee correr " << _nombrePrograma << ".time" <<
  endl;
#else
  cerr << TITULO_ERROR <<
  "No se puede abrir el archivo de time indicado ("<< nombreArchivo <<")." 
  << endl;
#endif
  exit(EXIT_FAILURE);
}
void ParserDeParametros::_imprimirErrorParametro( string parametro, string value ){
  cerr << TITULO_ERROR <<
"Se reconoció el parámetro: " << parametro <<"."
  << endl <<
"Sin embargo, no se reconoce el valor indicado (" << value << ")" << endl;
  exit(EXIT_FAILURE);
}
istream &ParserDeParametros::tipoInput ( void )
{ 
  return *_input; 
}
ostream &ParserDeParametros::tipoOutput ( void )
{ 
  return *_output; 
}
ostream &ParserDeParametros::tipoDebug ( void )
{ 
  return *_debug; 
}
ostream &ParserDeParametros::tipoTime ( void )
{ 
  return *_time; 
}
FactorySolucion::TipoSolucion ParserDeParametros::tipoDeSolucion ( void )
{ 
  return _tipoDeSolucion; 
}
FactorySolucion::TipoSolucion ParserDeParametros::tipoDeSolucionInicial ( void ) 
{
  return (FactorySolucion::TipoSolucion) _tipoDeSolucionInicial; 
}
uint32_t ParserDeParametros::tabuMaxTamanio( void )
{
  if (_tabu_max_tamanio > 0)
  {
    return _tabu_max_tamanio;
  }
  else
  {
    return 0;
  }
}
uint32_t ParserDeParametros::tabuMaxIteraciones( void )
{
  if (_tabu_max_iteraciones > 0)
  {
    return _tabu_max_iteraciones;
  }
  else
  {
    return 0;
  }
}
