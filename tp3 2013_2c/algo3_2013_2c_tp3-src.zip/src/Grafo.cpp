#include "Grafo.h"

/* Constructor */
Grafo::Grafo ( uint nodos, char tipo ):
  _cantidadDeNodos(nodos),
  _tipoDeAlmacenamiento(tipo)
{

  assert( nodos > 0 ); // Debe tener al menos un nodo
  /* La cantidad de aristas es <= nodos^2 */

  if ( this->_condicionMatrizDeAdyacencia() )
  {
    DEBUG_PRINT("Inicializando grafo con matriz de adyacencia...");
    _matrizDeAdyacencia = vector<vbool>(nodos, vbool(nodos*nodos, false));
    DEBUG_PRINT("-  Se creó una matriz en blanco de tamaño "<<nodos<<"x"<<nodos);
  }

  if ( this->_condicionListasDeAdyacencia() )
  {
    DEBUG_PRINT("Inicializando grafo con listas de adyacencia...");
    _listasDeSetDeAdyacencia = vector< set<uint> >(nodos);
    _listasDeVecDeAdyacencia = vector< vector< pair<uint,uint> > >(nodos);
    _listasDeVecDeAdyacenciaCalculada = vector<bool>(nodos, false);
  }

}
/* Destructor */

Grafo::~Grafo()
{

}

bool Grafo::_condicionListasDeAdyacencia() const
{

  return (_tipoDeAlmacenamiento == LISTAS_DE_ADYACENCIA || _tipoDeAlmacenamiento == MATRIZ_Y_LISTAS);

}

bool Grafo::_condicionMatrizDeAdyacencia() const
{

  return (_tipoDeAlmacenamiento == MATRIZ_DE_ADYACENCIA || _tipoDeAlmacenamiento == MATRIZ_Y_LISTAS);

}

/* Devuelve la cantidad de nodos del grafo */
uint Grafo::cantidadDeNodos(void) const
{

  return _cantidadDeNodos;

}

void Grafo::agregarArista(uint nodoInicial, uint nodoFinal)
{
    assert(nodoInicial >= 0 && nodoInicial < cantidadDeNodos());
    assert(nodoFinal >= 0 && nodoFinal < cantidadDeNodos());
    assert(nodoInicial != nodoFinal);

    if ( this->_condicionMatrizDeAdyacencia() )
    {
      _matrizDeAdyacencia[nodoInicial][nodoFinal] = true;
      _matrizDeAdyacencia[nodoFinal][nodoInicial] = true;
    }
    if ( this->_condicionListasDeAdyacencia() )
    {
      _listasDeSetDeAdyacencia[nodoInicial].insert(nodoFinal);
      _listasDeSetDeAdyacencia[nodoFinal].insert(nodoInicial);
    }
}

bool Grafo::sonAdyacentes(uint unNodo, uint otroNodo) const
{

  if( this->_condicionMatrizDeAdyacencia() )
  {
    return _matrizDeAdyacencia[unNodo][otroNodo];
  }
  else
  {
    return _listasDeSetDeAdyacencia[unNodo].count(otroNodo);
  }

}

uint Grafo::grado( uint unNodo )
{

  if ( this->_condicionListasDeAdyacencia() )
  {
    return _listasDeSetDeAdyacencia[unNodo].size();
  }
  else
  {
    return count(_matrizDeAdyacencia[unNodo].begin(), _matrizDeAdyacencia[unNodo].end(), true);
  }

}

set<uint> &Grafo::nodosAdyacentes( uint unNodo )
{

  assert(unNodo < _cantidadDeNodos);
  return _listasDeSetDeAdyacencia[unNodo];

}

vector< pair<uint, uint> > &Grafo::nodosAdyacentesOrdenadosPorGrado( uint unNodo )
{

  assert(unNodo < _cantidadDeNodos);
  assert( _listasDeVecDeAdyacenciaCalculada.size() == _cantidadDeNodos );

  if(this->_listasDeVecDeAdyacenciaCalculada[unNodo])
  {
    return (this->_listasDeVecDeAdyacencia[unNodo]);
  }

  else
  {
    for( set<uint32_t>::iterator it = this->_listasDeSetDeAdyacencia[unNodo].begin(); it != this->_listasDeSetDeAdyacencia[unNodo].end(); it++ )
    {
      uint nodoAdyacente = *it;
      pair<uint, uint> nodoAdyacentePair = make_pair(grado(nodoAdyacente),nodoAdyacente);
      this->_listasDeVecDeAdyacencia[unNodo].push_back(nodoAdyacentePair);
    }

    sort(_listasDeVecDeAdyacencia[unNodo].begin(),_listasDeVecDeAdyacencia[unNodo].end());
    return (this->_listasDeVecDeAdyacencia[unNodo]);
  }

}
