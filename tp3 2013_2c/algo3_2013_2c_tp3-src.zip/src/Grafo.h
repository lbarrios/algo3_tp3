#ifndef __GRAFO_H__
#define __GRAFO_H__
#include "headers/headers.h"
/**
 * Esta clase representa un grafo.
 */
class Grafo
{
public:
  // Tipos de almacenamiento
  enum { MATRIZ_DE_ADYACENCIA, LISTAS_DE_ADYACENCIA, MATRIZ_Y_LISTAS };
	/**
 	 * Constructor del grafo.
 	 * @param[in] cantidadDeNodos La cantidad de nodos del grafo.
 	 * @param[in] tipoDeAlmacenamiento El tipo de almacenamiento que utilizará la clase.
 	 */
  Grafo( uint cantidadDeNodos, char tipoDeAlmacenamiento );
  /**
   * Destructor del grafo.
   */
  ~Grafo();

////////////////////////////////////////////////////////////////////////////////
// Métodos Públicos para consultar el grafo
////////////////////////////////////////////////////////////////////////////////
  /**
   * Retorna la cantidad de nodos.
   */
  uint cantidadDeNodos() const;
  /**
   * Dados dos nodos del grafo indica si son adyacentes
   * @param  ID de un nodo
   * @param  ID de otro nodo
   * @return bool (unNodo "es adyacente de" otroNodo)
   */
  bool sonAdyacentes(uint, uint) const;
  /**
   * Dado un nodo devuelve la cantidad de nodos adyacentes
   * @param  uint ID de un nodo
   * @return      Cantidad de nodos adyacentes
   */
  uint grado(uint);
  /**
   * Dado un nodo devuelve un set con sus adyacentes
   * @param uint ID del nodo
   * @return     Set que contiene a los nodos adyacentes
   */
  set<uint> &nodosAdyacentes(uint);
  /**
   * Dado un nodo devuelve un vector con sus adyacentes
   * ordenados por grado.
   * @param uint ID del nodo
   * @return     Vector que contiene a los nodos adyacentes
   */
  vector< pair<uint, uint> > &nodosAdyacentesOrdenadosPorGrado(uint);

////////////////////////////////////////////////////////////////////////////////
// Métodos Públicos para modificar el grafo
////////////////////////////////////////////////////////////////////////////////
  /**
   * Agrega una arista al grafo.
   */
  void agregarArista(uint nodoInicial, uint nodoFinal);
  // Agrega un nodo al grafo
  //void agregarNodo();

private:
  uint _cantidadDeNodos; //< Cantidad de nodos del grafo
  char _tipoDeAlmacenamiento; //< Tipo de almacenamiento del grafo
  vector< vector<bool> > _matrizDeAdyacencia; //< Almacenamiento matriz (vec<bool>)
  vector< set<uint> > _listasDeSetDeAdyacencia; //< Almacenamiento por listas (set<uint>)
  vector< vector< pair<uint, uint> > > _listasDeVecDeAdyacencia; //< Almacenamiento por listas (vec<uint>)
  vector< bool > _listasDeVecDeAdyacenciaCalculada;

  bool _condicionListasDeAdyacencia() const;
  bool _condicionMatrizDeAdyacencia() const;
};
#endif
