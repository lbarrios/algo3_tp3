#include "headers/headers.h"
#include "ParserDeParametros.h"
#include "Grafo.h"
#include "FactorySolucion.h"
#include "Solucion.h"

#define INPUT_NULO 0

Grafo& leerGrafoDesdeInput(ParserDeParametros&, uint);
void imprimirOutput(ostream&, Solucion&);

#ifdef TIME
  uint cantidad_de_repeticiones=1; ///< Variable global
#endif
