#include "SolucionBusquedaLocal.h"


SolucionBusquedaLocal::SolucionBusquedaLocal(Grafo &grafo, FactorySolucion::TipoSolucion tipoSolucionInicial)
	:Solucion(grafo)
{
  DEBUG_PRINT("Inicializando algoritmo de búsqueda local.");
  if( tipoSolucionInicial==-1 )
    _tipoDeSolucionInicial = FactorySolucion::GREEDY;
  else
    this->_tipoDeSolucionInicial = tipoSolucionInicial;
}


SolucionBusquedaLocal::~SolucionBusquedaLocal()
{

}

void SolucionBusquedaLocal::resolver()
{
  // Obtengo primer solución, se guarda en _solucionTemporal
  this->_obtenerPrimerSolucionTemporal();
  // Itero mientras exista una solución vecina mejor
  while( this->_tamanioFronteraSolucionTemporal > this->_tamanioFronteraMejorSolucion ){
    DEBUG_PRINT("------------------------------------------------------------------------------------");
    DEBUG_PRINT("");
    DEBUG_PRINT("");
    DEBUG_PRINT("Se iterará porque se encontró una solución mejor a la 'mejor solución' del momento.");
    DEBUG_PRINT("");
    DEBUG_PRINT("");
    DEBUG_PRINT("------------------------------------- ITERACION ------------------------------------");
    DEBUG_PRINT("------------------------- (buscando el mejor de la vecindad) -----------------------");
    DEBUG_PRINT("");
    this->_guardarSolucionTemporal(); // Guardo a _mejorSolucion
    this->_obtenerMejorSolucionVecinaTemporal(); // obtengo siguiente _solucionTemporal
    DEBUG_PRINT("");
    DEBUG_PRINT("---------------------------------- FIN DE LA ITERACION -----------------------------");
  }
  DEBUG_PRINT("------------------------------------------------------------------------------------");
  DEBUG_PRINT("");
  DEBUG_PRINT("");
  DEBUG_PRINT("No se encontraron soluciones mejores a la última 'mejor solución' encontrada... :(");
  DEBUG_PRINT("");
  DEBUG_PRINT("");
  DEBUG_PRINT("------------------------------------------------------------------------------------");
  DEBUG_PRINT("------------------------------ FIN DE LAS ITERACIONES ------------------------------");
  DEBUG_PRINT("------------------------------------------------------------------------------------");

}

void SolucionBusquedaLocal::_obtenerPrimerSolucionTemporal(){
  FactorySolucion *factory = FactorySolucion::getInstance();
  
  if(_tipoDeSolucionInicial == FactorySolucion::GREEDY)
  {
    /* Instancio una solución GREEDY */
    Solucion *solucionGolosa;
    solucionGolosa = factory->crearSolucion(*(_grafo),FactorySolucion::GREEDY,FactorySolucion::GREEDY,0,0);
    solucionGolosa->resolver();
    vector<uint32_t> nodosSolucion = solucionGolosa->nodosSolucion();
    for(vector<uint32_t>::iterator nodo = nodosSolucion.begin(); nodo < nodosSolucion.end(); nodo++)
    {
      _solucionTemporalAgregaNodo(*nodo);
    }
    delete solucionGolosa;
    DEBUG_PRINT("Solución golosa obtenida.");
  }
  else if(_tipoDeSolucionInicial == FactorySolucion::NODO_RANDOM)
  {
    /* Instancio una solución RANDOM */
    srand(time(NULL));
    _solucionTemporalAgregaNodo(rand() % this->_grafo->cantidadDeNodos());
    DEBUG_PRINT("Solución random obtenida.");
  }
  else
  {
    cerr << "Ha ocurrido un error al obtener la primer solucion temporal." << endl;
    exit(EXIT_FAILURE);
  }
}

void SolucionBusquedaLocal::_obtenerMejorSolucionVecinaTemporal(){
	// Resguardo la mejor solución
	set<uint32_t> mejorSolucionAdyacente = set<uint32_t>(this->_mejorSolucion);
  uint32_t fronteraMejorSolucionAdyacente = this->_tamanioFronteraMejorSolucion;
  vector<uint32_t> mejorSolucionVector(this->_mejorSolucion.begin(), this->_mejorSolucion.end());
  int64_t cualAgrega=-1, cualQuita_i=-1, cualQuita_j=-1;
/*
	// Itero sobre los nodos de la clique
	set<uint>::iterator nodo = this->_solucionTemporal.begin();
  // Iterador de los adyacentes de un nodo determinado
	set< pair<uint,uint> >::iterator itAdyacentes;
*/
	
  // Para todos los nodos de la clique pruebo la vecindad formada por:
  // - Agregar un nodo circundante (clique.size++)
  // - Quitar un nodo de la cliqué y agregar un nodo circundante (intercambiar)
  // - Quitar dos nodos de la cliqué, y agregar un nodo circundante (clique.size--)
  for( int i=-1; i<(int)this->_mejorSolucion.size(); i++){
		if(i+1) {
      DEBUG2_PRINT("Removiendo (temporalmente) nodo "<<mejorSolucionVector[i]+1<<"...");
      this->_solucionTemporalRemueveNodo(mejorSolucionVector[i]);
    }
    for( int j=i; j<(int)this->_mejorSolucion.size(); j++){
      if((j+1) && (i-j)) {
        DEBUG2_PRINT("Removiendo (temporalmente) nodo "<<mejorSolucionVector[j]+1<<"...");
        this->_solucionTemporalRemueveNodo(mejorSolucionVector[j]);
      }

			
			/* Esto es un poco hackish... voy a recorrer la lista de adyacentes en sentido inverso
			 * aprovechando que dentro del set el pair<uint,uint> va a estar ordenado...
			 * lo que significa que primero me va a traer todos los nodos que pueden formar cliqué...
			 * ...(y detengo el bucle en cuanto llegue a alguno que no) */
			set< pair<uint32_t, uint32_t> > adyacentes = this->_adyacentesSolucionTemporal;
      set< pair<uint32_t, uint32_t> >::reverse_iterator nodoAdyacente = adyacentes.rbegin();
			//set< pair<uint32_t, uint32_t> >::reverse_iterator nodoAdyacente = this->_adyacentesSolucionTemporal.rbegin();
			while(nodoAdyacente!= adyacentes.rend() && this->_esCliqueConSolucionTemporal(nodoAdyacente->second)){
        if (
          ( (!(i+1))||(nodoAdyacente->second!=mejorSolucionVector[i]) )
          &&
          ( (!((j+1) && (i-j)))||(nodoAdyacente->second!=mejorSolucionVector[j]) )
        ){
          DEBUG2_PRINT("AGREGANDO NODO " << nodoAdyacente->second+1);
          // Agrego el nodo a mi solución temporal
  				this->_solucionTemporalAgregaNodo(nodoAdyacente->second);
  				// Si es mejor que la mejor de las soluciones adyacentes, la guardo
  				if( fronteraMejorSolucionAdyacente < _tamanioFronteraSolucionTemporal ){
            DEBUG2_PRINT("SE ENCONTRÓ UNA MEJOR FRONTERA ("<<_tamanioFronteraSolucionTemporal<<")");
  					mejorSolucionAdyacente = _solucionTemporal;
            fronteraMejorSolucionAdyacente = _tamanioFronteraSolucionTemporal;
            
            // Resguardo los valores de esta solución
            cualAgrega=nodoAdyacente->second;
            if(i+1){
              cualQuita_i = mejorSolucionVector[i];
            } else {
              cualQuita_i = -1;
            }
            if((j+1) && (i-j)){
              cualQuita_j = mejorSolucionVector[i];
            } else {
              cualQuita_j = -1;
            }
  				}
  				// Remuevo el nodo de mi solución temporal (todo queda como estaba antes)
  				this->_solucionTemporalRemueveNodo(nodoAdyacente->second);
          DEBUG2_PRINT("REMOVIENDO NODO " << nodoAdyacente->second+1);
        }
				nodoAdyacente++;
			}

      if((j+1) && (i-j)) {
        this->_solucionTemporalAgregaNodo(mejorSolucionVector[j]);
        DEBUG2_PRINT("Se vuelve a agregar el nodo "<<mejorSolucionVector[j]+1<<"...");
      }
    }
		if(i+1) {
      this->_solucionTemporalAgregaNodo(mejorSolucionVector[i]);
      DEBUG2_PRINT("Se vuelve a agregar el nodo "<<mejorSolucionVector[i]+1<<"...");
    }
  }
  
  if(cualAgrega+1){
    DEBUG_PRINT(endl<<"MODIFICANDO SOLUCION TEMPORAL PARA ADAPTARLA A LA MEJOR SOLUCION VECINA");
    this->_solucionTemporalAgregaNodo(cualAgrega);
    if(cualQuita_i+1){
      this->_solucionTemporalRemueveNodo(cualQuita_i);
    }
    if(cualQuita_j+1){
      this->_solucionTemporalRemueveNodo(cualQuita_j);
    }
  }
}


