#ifndef __SOLUCION_GREEDY_H__
#define __SOLUCION_GREEDY_H__

#include "Solucion.h"
#include "SelectorGreedy.h"

class SolucionGreedy: public Solucion {

public:
	/**
   * Inicializa una instancia de solución golosa
   * @param  Grafo  grafo por referencia
   * @param  SelectorGreedy  puntero a... [completar]
   * @return  Solucion
	 */
	SolucionGreedy( Grafo&, SelectorGreedy*);
	~SolucionGreedy();

	void resolver();
private:
	SelectorGreedy *selector;
	uint32_t ultimo_nodo; ///< Ultimo nodo agrgado a la solucion

};
#endif
