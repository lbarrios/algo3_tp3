#include "SolucionBT.h"

SolucionBT::SolucionBT( Grafo& grafo)
	:Solucion(grafo)
{

	DEBUG_PRINT("Resolviendo solución mediante algoritmo exacto (BT)");

}


SolucionBT::~SolucionBT()
{

}

void SolucionBT::resolver( void ) {

	for(uint32_t nodo=0; nodo< _grafo->cantidadDeNodos(); nodo++)
	{
		DEBUG_PRINT("Probando soluciones que tienen como primer nodo a nodo " << nodo+1);
		_resolverSolucionExactaBT( nodo );
	}

}

uint32_t SolucionBT::_maximoTamanioFrontera ( uint32_t cantidadDeNodosDeLaClique )
{

  // El tamanio maximo sera cuando haya una arista desde cada nodo de la clique a cada nodo del grafo
  // que no pertenezca a la clique, es decir, sumatoria(nodos_clique){ nodos(grafo) - nodos(clique) }
  // o, lo que es lo mismo, nodos(clique) * ( nodos(grafo)-nodos(clique) )
  return (uint32_t) ( _grafo->cantidadDeNodos() - cantidadDeNodosDeLaClique ) * cantidadDeNodosDeLaClique;

}

void SolucionBT::_resolverSolucionExactaBT( uint32_t nodoActual ) {

  // Poda para ver si me sirve seguir buscando fronteras
  uint32_t cantidadDeNodosDeLaNuevaClique = _solucionTemporal.size() + 1;
  if ( cantidadDeNodosDeLaNuevaClique >= (uint32_t) (_grafo->cantidadDeNodos()/2) )
  {
    if ( _tamanioFronteraMejorSolucion >= this->_maximoTamanioFrontera(cantidadDeNodosDeLaNuevaClique) )
    {
      // Si "ya no puedo" obtener una solución más grande que la mejor, entonces aplico poda.
      DEBUG2_PRINT("Aplicando poda porque el tamanio de la mejor solución ("<<_tamanioFronteraMejorSolucion<<") es" << endl
      <<"mas grande que el maximo tamanio posible de frontera que se puede obtener con " << _solucionTemporal.size() + 1 << " nodos.");
      return;
    }
  }

  /// Agrego el nodo a mi solución temporal
  _solucionTemporalAgregaNodo( nodoActual );

  /// Si es mejor solución la guardo
  if( _tamanioFronteraMejorSolucion < _tamanioFronteraSolucionTemporal )
  {
  	DEBUG2_PRINT("El tamaño de la nueva frontera es mejor, guardando nueva 'mejor solucion'");
    _guardarSolucionTemporal();
  }

  /// Me fijo el siguiente nodo que forme cliqué con mi nueva solución temporal
  for(uint siguienteNodo = nodoActual+1; siguienteNodo < _grafo->cantidadDeNodos(); siguienteNodo++){
    if(_esCliqueConSolucionTemporal( siguienteNodo ))
    {
    	DEBUG2_PRINT("El nodo " << siguienteNodo+1 << " puede formar un clique con la solucion temporal, haciendo recursion...");
      _resolverSolucionExactaBT( siguienteNodo );
    }
  }

  /// Remuevo el nodo de mi solución temporal
  _solucionTemporalRemueveNodo( nodoActual );

}
