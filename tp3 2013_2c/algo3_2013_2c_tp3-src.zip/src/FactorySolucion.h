
#ifndef __FACTORYSOLUCION_H__
#define __FACTORYSOLUCION_H__
#include "Solucion.h"

/*Singleton FactorySolucion*/
class FactorySolucion{
public:
	enum TipoSolucion {BACKTRACKING,GREEDY,BUSQUEDA_LOCAL,BUSQUEDA_TABU,NODO_RANDOM};
	
	/* Inicializa única instancia de Factory */
	static void init(){
		instance = NULL;
		instance = new FactorySolucion();
	};
	/** Elimina instancia de factory 
	 * Pre: haber inicializado singleton con metodo statico init() 
     */
	static void end(){
		if(instance){
			delete instance;
			instance = NULL;
		}

	};
	/** Devuelve instancia de singleton Factory Solucion 
	 * Pre: haber inicializado singleton con metodo statico init() 
     */
	static FactorySolucion *getInstance(){
		return instance;
	};
	
	
  /**
   *  Crear instancia de Solucion.
   */
	Solucion *crearSolucion(Grafo&,TipoSolucion,TipoSolucion,uint32_t,uint32_t);
protected:
	static FactorySolucion *instance;
private:
	FactorySolucion();
	~FactorySolucion();
};

#endif

