#include "SelectorPorGrado.h"

SelectorPorGrado::SelectorPorGrado(Grafo &grafo)
	:SelectorGreedy(grafo)
{
	nodos_por_grado.reserve(grafo.cantidadDeNodos());
	for( uint32_t i = 0; i < grafo.cantidadDeNodos();i++ )
		nodos_por_grado.push_back(make_pair(grafo.grado(i),i));

	make_heap(nodos_por_grado.begin(),nodos_por_grado.end());
	sort_heap(nodos_por_grado.begin(),nodos_por_grado.end());
	proximo = nodos_por_grado.rbegin();
	
}

SelectorPorGrado::~SelectorPorGrado(){

}

pair<uint32_t,uint32_t> SelectorPorGrado::obtenerMaximoLocal(unsigned int nodo){
	pair<uint32_t,uint32_t> par_grado_nodo;

	if( proximo == nodos_por_grado.rend() ){
		DEBUG2_PRINT("Se llegó al final de la lista de nodos.");
		par_grado_nodo = make_pair(0,0);
	}else{
		DEBUG2_PRINT("El próximo nodo es " << proximo->second << ".");
		par_grado_nodo = (*proximo);
		proximo++;
	}
	
	return par_grado_nodo;

}

