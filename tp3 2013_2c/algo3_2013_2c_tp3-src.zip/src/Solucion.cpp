#include "Solucion.h"

Solucion::Solucion(Grafo& g){
  _grafo = &g;
  
  // Inicializo contadores en null
  _tamanioFronteraMejorSolucion=0;
  _tamanioFronteraSolucionTemporal=0;
  
  // Reservo/asigno espacio para las estructuras
  _adyacentesSolucionTemporal_presente.assign( g.cantidadDeNodos(), false );
  DEBUG2_PRINT("Asignando "<<g.cantidadDeNodos()<<" posiciones en false para el vector de booleanos de adyacencias de clique...");
  _adyacentesSolucionTemporal_puntero.reserve( g.cantidadDeNodos() );
  DEBUG2_PRINT("Reservando "<<g.cantidadDeNodos()<<" posiciones para el vector de punteros a adyacencias de clique...");
}
Solucion::~Solucion(){
}

uint Solucion::tamanioFrontera(){
  return _tamanioFronteraMejorSolucion;
}
uint Solucion::tamanioClique(){
  return _mejorSolucion.size();
}
/*
uint Solucion::nodo( uint ){
  return 0;
}
*/
vector<uint32_t> Solucion::nodosSolucion( void ){
/*
  vuint solucion;
  set<uint>::iterator nodo = _mejorSolucion.begin();
  while( nodo != _mejorSolucion.end() ){
    solucion.push_back((*nodo)+1);
    nodo++;
  }
  return solucion;
*/
  return vuint(_mejorSolucion.begin(),_mejorSolucion.end());
}

void Solucion::_imprimeDebugSolucion( void ){
  /// [v1,v2,...,vn]+vx
  DEBUG_COUT ("[");
  //foreach(n,_solucionTemporal){
  for(set<uint>::iterator n = _solucionTemporal.begin();n!=_solucionTemporal.end();n++){
    uint dist = distance(_solucionTemporal.begin(),n);
    if(dist+1<_solucionTemporal.size()) {
      if(dist+2<_solucionTemporal.size()) {
        DEBUG_COUT (*n+1<<",");
      } else {
        DEBUG_COUT (*n+1);
      }
    } else {
      DEBUG_COUT ("]+" << *n+1);
    }
  }
  /// espacios
  if(_solucionTemporal.size()>1) DEBUG_COUT (" ");
  
  for(int spaces=0;spaces<20-(int)(_solucionTemporal.size()*2);spaces++) DEBUG_COUT (" ");

  /// f_act=TAMANIO_FRONTERA_SOLUCION_TEMPORAL
  DEBUG_COUT ("f_act=");
  DEBUG_COUT (_tamanioFronteraSolucionTemporal);
  /// espacios
  for(int spaces=0;spaces<6-(int)(_tamanioFronteraSolucionTemporal/10);spaces++) DEBUG_COUT (" ");

  /// f_max=TAMANIO_FRONTERA_MEJOR_SOLUCION
  DEBUG_COUT ("f_max="<<_tamanioFronteraMejorSolucion<<endl);
}
void Solucion::_solucionTemporalAgregaNodo( uint32_t nodo ) {
  assert(_solucionTemporal.count(nodo)==0);
  /*
  	Se le quitan los nodos que estaban en la frontera de la clique (solucionTemporal.size())
  	y se le agregan los del grado del nodo que pertenecen a la clique (solicionTemporal.size).
  	O sea fontera = frontera - ST.size + grado(nodo) - ST.size = frontera + grado(nodo) -2*ST.size
  */
  _tamanioFronteraSolucionTemporal+=_grafo->grado(nodo)-(2*_solucionTemporal.size());
  _solucionTemporal.insert(nodo); ///< Agrego el nodo a mi solución temporal
	DEBUG2_PRINT("Insertando nodo "<<nodo+1);
  DEBUG2_PRINT("El tamaño de la frontera de la nueva solucion es "<<_tamanioFronteraSolucionTemporal);

  /*if( _tamanioFronteraMejorSolucion < _tamanioFronteraSolucionTemporal ){
    _guardarSolucionTemporal();
  }*/


  /*
     Esta verificación no sería necesaria...
  pero al agregar el PRIMER nodo el programa tira segmentation fault.
     ¿Lo correcto sería verificar miles de veces, sabiendo que si estoy
  agregando un nodo, es porque estaba adyacente a mi solucion anterior,
     o manosear un poco el vector de adyacentes a solucion temporal
     ANTES de agregar el primer nodo, de forma que todo vaya bien?

  Es más prolijo agregar esta verificación aquí... pero
  ¿agregará una constante considerable tener que verificar esto en cada ejecución?
  */
  if( _adyacentesSolucionTemporal_presente[nodo] ){
  	// Borro el nodo de la lista de nodos adyacentes a la cliqué
  	// PD: Nada puede malir sal porque sé que tiene exactamente (clique_size) aristas
  	_adyacentesSolucionTemporal_presente[nodo] = false;
  	DEBUG2_PRINT("El nodo " << nodo+1 << " ya no es adyacente a la clique.");
  	// No actualizo el puntero porque para eso lo estoy marcando "NO presente"
  	// Lo borro de la lista con erase(iterador) => borra en tiempo constante
  	_adyacentesSolucionTemporal.erase(_adyacentesSolucionTemporal_puntero[nodo]);
  }

 	DEBUG2_PRINT("Recorriendo la lista de nodos adyacentes a " << nodo+1);
  // Recorro los nodos adyacentes al nodo que estoy agregando
  // Y los refresco/agrego en la lista de nodos adyacentes a la cliqué
  for (set<uint32_t>::iterator nodoAdyacente=_grafo->nodosAdyacentes( nodo ).begin(); nodoAdyacente!=_grafo->nodosAdyacentes( nodo ).end(); nodoAdyacente++){
    // Si el nodo adyacente pertenece a mi cliqué, entonces NO hago nada.
    if( !_solucionTemporal . count(*nodoAdyacente) ){ // count == 1 si está, 0 si no está
    	DEBUG2_PRINT("  El nodo " << *nodoAdyacente +1 << " es adyacente y todavia no pertenece a la clique.");
      // Lo busco en el vector de booleanos para ver si era adyacente a alguno
      if(_adyacentesSolucionTemporal_presente[*nodoAdyacente]){
        // Si ya era adyacente a alguno, lo obtengo, lo elimino, y lo vuelvo a agregar, sumando una arista
        uint32_t cantidadDeAristas = _adyacentesSolucionTemporal_puntero[*nodoAdyacente]->first;
      	DEBUG2_PRINT("    El nodo " << *nodoAdyacente +1 << " ya estaba en la lista de adyacencia de la clique con "<<cantidadDeAristas<<" aristas.");
        // lo borro usando erase(iterador) => borra en tiempo constante
        _adyacentesSolucionTemporal.erase( _adyacentesSolucionTemporal_puntero[*nodoAdyacente] );
        _adyacentesSolucionTemporal_puntero[*nodoAdyacente] = _adyacentesSolucionTemporal.insert(make_pair(cantidadDeAristas+1, *nodoAdyacente)).first; // (*cualquier cosa, ver REF_SET_INSERT)
        //_adyacentesSolucionTemporal_presente[*nodoAdyacente] = true;
      } else {
      	DEBUG2_PRINT("    El nodo " << *nodoAdyacente +1 << " no estaba en la lista de adyacencia de la clique.");
        // Sino, lo agrego con 1 arista porque sé que no es adyacente a ningun otro de la cliqué
        _adyacentesSolucionTemporal_puntero[*nodoAdyacente] = _adyacentesSolucionTemporal.insert( make_pair(1, *nodoAdyacente) ).first; // (*cualquier cosa, ver REF_SET_INSERT)
        _adyacentesSolucionTemporal_presente[*nodoAdyacente] = true;
      }
    }
  }

  /* REF_SET_INSERT
   * From http://www.cplusplus.com/reference/set/set/insert/ 
   *
   * The single element versions (1) return a pair, with its member pair::first 
   * set to an iterator pointing to either the newly inserted element or to the 
   * equivalent element already in the set. The pair::second element in the pair 
   * is set to true if a new element was inserted or false if an equivalent element 
   * already existed.
   *
   * O sea que set->insert(...)->first me devuelve un iterador a lo que inserté.
   */

  #ifdef DEBUG
    _imprimeDebugSolucion( );
  #endif
}

void Solucion::_solucionTemporalRemueveNodo( uint nodo )
{
  assert(_solucionTemporal.count(nodo)>0);
  DEBUG2_PRINT("Removiendo nodo "<<nodo+1<<" de la solución temporal");
  _solucionTemporal.erase(nodo); ///< Quito el nodo de mi solución temporal
  _tamanioFronteraSolucionTemporal -= (   _grafo->grado(nodo) - (2*_solucionTemporal.size())   ); ///< Resto el grado del nodo
  DEBUG2_PRINT("El tamaño de la nueva frontera es " << _tamanioFronteraSolucionTemporal);

  if ( _solucionTemporal.size() ) { // Si la cliqué me queda vacía, "no hay adyacentes"
  	// Agrego el nodo que acabo de sacar a la lista de nodos adyacentes de la cliqué
  	// PD: Sé que tiene exactamente (clique_size) aristas... porque ESTABA en la cliqué
  	// y por la misma razón se que no estaba en la lista de adyacentes. Siempre que nada malga sal...
  	_adyacentesSolucionTemporal_puntero[nodo] = _adyacentesSolucionTemporal.insert(make_pair(_solucionTemporal.size(), nodo)).first;
  	// Actualizo el puntero (ver REF_SET_INSERT), y lo marco como "presente"...
  	_adyacentesSolucionTemporal_presente[nodo] = true;
  	DEBUG2_PRINT("El nodo " << nodo+1 << " ahora es adyacente a la clique con " << _solucionTemporal.size() << " aristas...");
 	} else {
		_adyacentesSolucionTemporal_presente[nodo] = false;
  }

  // Recorro los nodos adyacentes al nodo que estoy removiendo
  // ...y los refresco/remuevo en la lista de nodos adyacentes a la cliqué
  for (set<uint32_t>::iterator nodoAdyacente=_grafo->nodosAdyacentes( nodo ).begin(); nodoAdyacente!=_grafo->nodosAdyacentes( nodo ).end(); nodoAdyacente++){
    // Todos los nodos adyacentes a este nodo en teoría EN TEORÍA deberían ser adyacentes a mi cliqué
    // Obtengo la cantidad de aristas que tendrá el nodo con la cliqué (a cantidad actual resto 1)

    if( _adyacentesSolucionTemporal_presente[*nodoAdyacente] ) { //   (lo de arriba es válido excepto para los que ya están en mi cliqué...)
    	uint32_t cantidadDeAristas = _adyacentesSolucionTemporal_puntero[*nodoAdyacente]->first;
    	DEBUG2_PRINT("El nodo " << *nodoAdyacente << " era adyacente a mi clique con " << cantidadDeAristas << " aristas...");
    	// erase recibe un iterador como parámetro => borra en tiempo constante
    	_adyacentesSolucionTemporal.erase(_adyacentesSolucionTemporal_puntero[*nodoAdyacente]);
    	// Si ya era adyacente a alguno, lo vuelvo a agregar restando una arista
    	if(--cantidadDeAristas){
    		DEBUG2_PRINT("El nodo " << *nodoAdyacente << " permanece en lista de adyacencia de clique porque todavia es adyacente a " << cantidadDeAristas << " nodos...");
	      _adyacentesSolucionTemporal_puntero[*nodoAdyacente] = _adyacentesSolucionTemporal.insert(make_pair(cantidadDeAristas, *nodoAdyacente)).first;
      	//_adyacentesSolucionTemporal_presente[*nodoAdyacente] = true;
    	}
    	else{
    		DEBUG2_PRINT("Borrando " << *nodoAdyacente << " de lista de adyacencia de clique porque solo era adyacente a nodo " << nodo);
	      // Si el único adyacente era el nodo que acabo de borrar, entonces lo marco "no adyacente"
      	_adyacentesSolucionTemporal_presente[*nodoAdyacente] = false;
    	}
    }
  }
}

bool Solucion::_esCliqueConSolucionTemporal( uint nodo )
{
  // El nodo debe ser adyacente a mi cliqué...! Si es así, verifico que la cantidad de aristas adyacentes sea igual al tamaño de la cliqué.
  #ifndef DEBUG
    return (
      (this->_adyacentesSolucionTemporal_presente[nodo]) && (this->_adyacentesSolucionTemporal_puntero[nodo]->first==_solucionTemporal.size())
    ) || (
      !this->_solucionTemporal.size()
    );
  #endif
  /////////////////////////////
  // DEBAJO SOLO DEBUG
	if ( this->_adyacentesSolucionTemporal_presente[nodo] ) {
		DEBUG2_PRINT("  El nodo " << nodo+1 << " es adyacente a la clique temporal con " << _adyacentesSolucionTemporal_puntero[nodo]->first << " aristas...");
		if(_adyacentesSolucionTemporal_puntero[nodo]->first==_solucionTemporal.size()){
			DEBUG2_PRINT("    El nodo " << nodo+1 << " puede formar cliqué.");
      return true;
		} else {
			DEBUG2_PRINT("    El nodo " << nodo+1 << " no puede formar cliqué");
      return false;
		}
  } else {
    if ( !this->_solucionTemporal.size() ){
      DEBUG2_PRINT("    El grafo está vacío, así que cualquier nodo es cliqué (en particular el nodo " << nodo+1 << ")...");
      return true;
    } else {
      DEBUG2_PRINT("    El nodo " << nodo+1 << " no es adyacente a la solución temporal.");
      return false;
    }
	}
}

void Solucion::_guardarSolucionTemporal()
{
  //~ cerr << "DBG: Guardando solución temporal como mejor solución" << endl;
  _tamanioFronteraMejorSolucion = _tamanioFronteraSolucionTemporal;
  _mejorSolucion = _solucionTemporal;
}
