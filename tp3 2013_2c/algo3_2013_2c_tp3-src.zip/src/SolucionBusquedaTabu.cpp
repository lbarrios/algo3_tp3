
#include <cstdlib>
#include <cmath>


#include "SolucionBusquedaTabu.h"

#define NO_ES_TABU -1
#define NIL -1


SolucionBusquedaTabu::SolucionBusquedaTabu(Grafo &grafo, FactorySolucion::TipoSolucion tipo_solucion_inicial,int max_tabu_size,int max_itr)
	:Solucion(grafo)
{
	this->tipo_solucion_inicial = tipo_solucion_inicial;
	if( !max_tabu_size ){
		this->max_tabu_size =  (_grafo->cantidadDeNodos()) / 3;
		if( this->max_tabu_size == 0 )
			this->max_tabu_size++;
	}else this->max_tabu_size = max_tabu_size;
	
	if( !max_itr ){
		if( this->tipo_solucion_inicial == FactorySolucion::GREEDY ){
			this->max_itr = pow(log(_grafo->cantidadDeNodos()),2);
			if( this->max_itr == 0 )
				this->max_itr = 2;
		}else this->max_itr = _grafo->cantidadDeNodos() / 2;
	}else this->max_itr = max_itr;

	lista_tabu.resize(this->max_tabu_size,SetNodos());
	tabu_itr = lista_tabu.begin();
	solucion_temporal_tabu_rank = NO_ES_TABU;
}



SolucionBusquedaTabu::~SolucionBusquedaTabu()
{
	
}

void SolucionBusquedaTabu::resolver()
{
	int itr_count = 0;
	this->obtenerSolucionInicial();
	this->agregarAListaTabu();
	while( itr_count < max_itr ){
		if(!obtenerMejorSolucionVecindad())
			itr_count++;
		else {
			this->_guardarSolucionTemporal();
			itr_count = 0;
		}
		DEBUG_COUT("Frontera " << this->_tamanioFronteraSolucionTemporal<< endl);
		this->agregarAListaTabu();
	}
}


void SolucionBusquedaTabu::obtenerSolucionInicial(){

	if( this->tipo_solucion_inicial == FactorySolucion::GREEDY ){
		FactorySolucion *factory = FactorySolucion::getInstance();
		 Solucion *solucion = factory->crearSolucion(*(this->_grafo),FactorySolucion::GREEDY,FactorySolucion::GREEDY,0,0);
		solucion->resolver();
		//Podria devolver un iterador ...
		VectorNodos nodos = solucion->nodosSolucion();
		for( VectorNodos::iterator itr = nodos.begin(); itr != nodos.end();itr++)
			this->_solucionTemporalAgregaNodo(*itr);
	}else if( this->tipo_solucion_inicial == FactorySolucion::NODO_RANDOM ){
		srand(time(NULL));
		this->_solucionTemporalAgregaNodo(rand() % this->_grafo->cantidadDeNodos());
	}
	this->_guardarSolucionTemporal();
}

bool SolucionBusquedaTabu::mejoroSolucionVecindad(int &mejor_frontera_vecindad,int &mejor_tabu_vecindad){
	int nuevo_rank_tabu = esTabu();
	if(   ( nuevo_rank_tabu == NO_ES_TABU &&  (int)_tamanioFronteraSolucionTemporal > mejor_frontera_vecindad ) 
		|| (   mejor_tabu_vecindad > nuevo_rank_tabu )){
		mejor_frontera_vecindad = _tamanioFronteraSolucionTemporal;
		mejor_tabu_vecindad = nuevo_rank_tabu;
		return true;
	}

	return false;
}

int SolucionBusquedaTabu::obtenerMejorSolucionVecindad(){

	int mejor_frontera_vecindad = -1;
	int mejor_tabu_vecindad= max_tabu_size + 1;
	VectorNodos vsolucion;
	int action = -1;
	pair<int,int> nodos(-1,-1);
	//Analizo agregar nodo de frontera a solucion actual	
	for( uint32_t i = 0; i < _grafo->cantidadDeNodos(); i++ ){
		if( _adyacentesSolucionTemporal_presente[i] && _esCliqueConSolucionTemporal(i) ){
			_solucionTemporalAgregaNodo(i);
			if( mejoroSolucionVecindad(mejor_frontera_vecindad,mejor_tabu_vecindad)  ){
				action = ADD;
				nodos.first = i;
			}
			_solucionTemporalRemueveNodo(i);
		}
	}
	//Analizo borra nodo de frontera a solucion actual	
	copy(_solucionTemporal.begin(), _solucionTemporal.end(), std::back_inserter(vsolucion));
	int size_temporal = vsolucion.size();
	for( int i = 0; i < size_temporal ; i++ ){
			_solucionTemporalRemueveNodo(vsolucion[i]);
			if( mejoroSolucionVecindad(mejor_frontera_vecindad,mejor_tabu_vecindad)  ){
				action = DEL;
				nodos.first = vsolucion[i];
			}
			_solucionTemporalAgregaNodo(vsolucion[i]);
	}
	
	//Swap entre nodo de frontera y nodo de solucion
	vector<bool> adyacentes_inicial = _adyacentesSolucionTemporal_presente;
	for( int i = 0; i < size_temporal ; i++ ){
		_solucionTemporalRemueveNodo(vsolucion[i]);
		for( uint32_t j = 0; j < _grafo->cantidadDeNodos(); j++ ){
			if(  adyacentes_inicial[j] && ( _esCliqueConSolucionTemporal(j) && _solucionTemporal.size() == 0 ) ){
				_solucionTemporalAgregaNodo(j);
				if( mejoroSolucionVecindad(mejor_frontera_vecindad,mejor_tabu_vecindad)  ){
					action = SWAP;
					nodos.first = vsolucion[i];
					nodos.second = j;
				}
				_solucionTemporalRemueveNodo(j);
			}
		}
		_solucionTemporalAgregaNodo(vsolucion[i]);
	}

	switch(action){
		case ADD:
			_solucionTemporalAgregaNodo(nodos.first);
			break;
		case DEL:
			_solucionTemporalRemueveNodo(nodos.first);
			break;
		case SWAP:
			_solucionTemporalRemueveNodo(nodos.first);
			_solucionTemporalAgregaNodo(nodos.second);
			break;
		}
	this->solucion_temporal_tabu_rank = mejor_tabu_vecindad;
	if( this->_tamanioFronteraSolucionTemporal > this->_tamanioFronteraMejorSolucion )
		return 1;
	else return 0;
}


void SolucionBusquedaTabu::agregarAListaTabu(){

	if( solucion_temporal_tabu_rank == NO_ES_TABU ){	
		(*tabu_itr) = _solucionTemporal;
		tabu_itr++;
		if( tabu_itr == lista_tabu.end())
			tabu_itr = lista_tabu.begin();
	}else if( solucion_temporal_tabu_rank != max_tabu_size ){
		ListaTabu::iterator itr;
		SetNodos aux;
		int dist_to_end = abs(distance(lista_tabu.end(),tabu_itr));
		if(  solucion_temporal_tabu_rank <  dist_to_end ){
			itr = tabu_itr + solucion_temporal_tabu_rank;
			while( itr <  lista_tabu.end() - 1 ){
				aux = (*itr);
				(*itr) = (*(itr+1));
				itr++;
				(*itr) = aux;
			}
			aux = (*itr);
			(*itr) = (*(lista_tabu.begin()));
			itr = lista_tabu.begin();	
			(*itr) = aux;
		}else{
			itr = lista_tabu.begin() + ( solucion_temporal_tabu_rank - dist_to_end );
		}
		while( itr <  tabu_itr - 1 ){
			aux = (*itr);
			(*itr) = (*(itr+1));
			itr++;
			(*itr) = aux;
		}
		
	}
}


int SolucionBusquedaTabu::esTabu(){
	ListaTabu::iterator solucion	= lista_tabu.begin();
	while( solucion != lista_tabu.end() ){
		SetNodos::iterator itr1 = (*solucion).begin();
		SetNodos::iterator itr2 = _solucionTemporal.begin();
		while( itr1 != (*solucion).end() && itr2 != _solucionTemporal.end() ){
			if( (*itr1) != (*itr2) )
				break;
			itr1++,itr2++;
		}
		if( itr1 == (*solucion).end() && itr2 == _solucionTemporal.end() ){
			if( solucion == tabu_itr )
				return 0;
			else if( solucion > tabu_itr )
				return abs(distance(solucion,tabu_itr));
			else return abs(distance(tabu_itr,lista_tabu.end())) + abs(distance(lista_tabu.begin(),solucion)) + 1;
		}
	solucion++;
	}
		
	return NO_ES_TABU;
}


