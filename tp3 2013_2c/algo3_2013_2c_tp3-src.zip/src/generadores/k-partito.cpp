

#include <iostream>
#include <sstream>
#include <ctime>
#include <sys/time.h>
#include <vector>
#include <cstdlib>
#include <fstream>

using namespace std;

int main(int argc,char **argv)
{

	if( argc < 5 ){
		cout << "Generacion de grafos en los cuales se puede dividir a sus nodos en al menos k particiones disjuntas" << endl;
		cout << "k-partito <outdir> <seq num> <nodos> <k>" << endl;
		exit(1);
	}
	struct timeval tv;
	gettimeofday(&tv,NULL);
	srand(tv.tv_usec);	
	int conjuntos = atoi(argv[4]);
	int nodos = atoi(argv[3]);
	vector< int > nodos_por_conjunto(conjuntos,0);
	int restantes = nodos;
	for( int i = 0; i < conjuntos -1 ; i++ )
		nodos_por_conjunto[i] = 1;
	restantes -= conjuntos;
	for( int i = 0; i < conjuntos -1 ; i++ ){
		if( (restantes /  ( conjuntos-i) ) == 0)
			break;
		int extra = rand() % (restantes /  ( conjuntos-i) ) + 1 ;	
		nodos_por_conjunto[i] += extra;
		restantes -= extra; 
		if( !restantes)
			break;
	}	
	nodos_por_conjunto[conjuntos-1] = restantes;

	
	for( int i = 0; i < conjuntos; i++ )
		cout << i << " -> " << nodos_por_conjunto[i] << endl;

	int cantidad_aristas = 0;
	
	ofstream out;
	stringstream tmp;
	string file_name;
	ostringstream convert;   // stream used for the conversion

	convert << time(NULL);
	file_name = argv[1];
	file_name +=  "/kp." + convert.str()  + "." + argv[2] +  ".in";
	out.open(file_name.c_str());
	out << nodos << " ";
	int base_from = 0;
	int base_to = 0;
	for( int i = 0; i < conjuntos -1 ; i++ ){
		if( i > 0 )
			base_from += nodos_por_conjunto[i-1];
		base_to += nodos_por_conjunto[i];	
		for( int j = 0; j < nodos_por_conjunto[i]; j++){
			for( int k = 0; k < nodos_por_conjunto[i + 1]; k++){
				if( rand() % 2 ){
					cantidad_aristas++;
					tmp << base_from + j  + 1 << " " <<  base_to + k  + 1<< endl;
				}

			}
		}

		gettimeofday(&tv,NULL);
		srand(tv.tv_usec);	
	}
	

	out << cantidad_aristas << endl;	
	out << tmp.rdbuf();
	out << "0" << endl;
	out.close();	
	return 0;
}
