#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <set>

using namespace std;

typedef int Vertice;
typedef pair<int,pair<Vertice,Vertice> > Arista;
typedef vector<Arista> VectorAristas;
typedef vector< set<int> > VectorAdyacencias;


int main(int argc,char **argv)
{
	
	if(argc < 2){
		cout << "Usage: " << argv[0] << " <max_n> " << endl;
		exit(1);
	}

	int max_n = atoi(argv[1]);
	int aristas = 0;
	srand(time(NULL));  
	cout <<  max_n << " " << ((max_n * (max_n -1 )) /2 )<< endl;
	for( int i = 1; i <= max_n; i++)
		for( int j = i + 1; j <= max_n;j++){
			cout << i << " " << j << " " << endl;
		}
	
	cout << "0" << endl;
	return 0;
}
