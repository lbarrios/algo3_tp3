

#include <iostream>
#include <sstream>
#include <ctime>
#include <sys/time.h>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <set>

using namespace std;

int main(int argc,char **argv)
{

	if( argc < 5 ){
		cout << "Generacion de grafos con al menos k componentes conexas" << endl;
		cout << "no_conexo <outdir> <seq num> <nodo> <k>" << endl;
		exit(1);
	}
	struct timeval tv;
	gettimeofday(&tv,NULL);
	srand(tv.tv_usec);	
	int componentes = atoi(argv[4]);
	int nodos = atoi(argv[3]);
	vector< int > nodos_por_componente(componentes,0);
	int restantes = nodos ;
	for( int i = 0; i < componentes ; i++ ){
		nodos_por_componente[i] =  nodos / ( componentes + 2 );
		restantes -= nodos / ( componentes + 2 );
	}

	for( int i = 0; i < componentes -1 ; i++ ){
		int extra = rand() %  restantes ;
		nodos_por_componente[i] +=  extra;
		restantes -= extra;
		if( !restantes)
			break;
	}	
	nodos_por_componente[componentes-1] += restantes;

	
	for( int i = 0; i < componentes; i++ )
		cout << i << " -> " << nodos_por_componente[i] << endl;

	int cantidad_aristas = 0;
	int suma_grado = 0;
	
	ofstream out;
	stringstream tmp;
	string file_name = argv[1];
	ostringstream convert;   // stream used for the conversion

	convert << time(NULL);
	file_name +=  "/nc." + convert.str()  + "." + argv[2];
	file_name +=  ".in";

	out.open(file_name.c_str());
	out << nodos << " ";
	int base = 0;
	for( int c = 0; c < componentes ; c++ ){
		if( c > 0 )
			base += nodos_por_componente[c-1];	
		vector< set<int> >vecinos(nodos_por_componente[c]);
		for( int i = 0; i < nodos_por_componente[c] - 1; i++){
				int grado = rand() % (nodos_por_componente[c]-1 ) + 1;
				if( grado < vecinos[i].size() )
					grado = vecinos[i].size();
				int j = vecinos[i].size();
				while( j < grado ){
					int vecino = rand() % nodos_por_componente[c];
					if( vecino != i && vecinos[i].find(vecino) == vecinos[i].end() ){
						tmp << base + i + 1 << " " << base + vecino + 1<< endl;
						vecinos[i].insert(vecino);
						vecinos[vecino].insert(i);
						j++;
					}else if( vecinos[i].find(vecino) == vecinos[i].end() ){
						j++;
					}
				}

			}
		
		gettimeofday(&tv,NULL);
		srand(tv.tv_usec);	
		suma_grado  = 0;
		for( int i = 0; i < nodos_por_componente[c];i++ )
			suma_grado += vecinos[i].size();
		cantidad_aristas += suma_grado / 2;	
		}
	
	
	out << cantidad_aristas << endl;	
	out << tmp.rdbuf();
	out << "0" << endl;

	out.close();	
	cout << file_name << endl;
	return 0;
}
