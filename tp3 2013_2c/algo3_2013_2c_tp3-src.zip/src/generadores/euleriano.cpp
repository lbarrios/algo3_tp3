

#include <iostream>
#include <sstream>
#include <ctime>
#include <sys/time.h>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <set>

using namespace std;

int main(int argc,char **argv)
{

	if( argc < 4 ){
		cout << "Generacion de grafos Eulerianos" << endl;
		cout << "euleriano <outdir> <seq num> <nodos>" << endl;
		exit(1);
	}
	struct timeval tv;
	gettimeofday(&tv,NULL);
	srand(tv.tv_usec);	
	int nodos = atoi(argv[3]);

	int cantidad_aristas = 0;
	int suma_grado = 0;
	
	ofstream out;

	stringstream tmp;
	string file_name;
	ostringstream convert;   // stream used for the conversion
	convert << time(NULL);
	vector< set<int> >vecinos(nodos);
	for( int i = 0; i < nodos - 1; i++ ){
		int grado = rand() % (nodos -1 -i );
		if ( grado % 2 )//Si el grado no es par lo hago par
			grado--;	
		if ( vecinos[i].size() > grado ){
			if( vecinos[i].size() % 2  )
				grado = vecinos[i].size() +1;
			if( grado == nodos )
				return 1;
		}
		int j = vecinos[i].size();
		while( j < grado ){
			int vecino = ( rand() % (nodos -i  )) + i  ;
			if( vecino != i && vecinos[i].find(vecino) == vecinos[i].end() ){
				tmp << i + 1 << " " << vecino + 1<< endl;
				vecinos[i].insert(vecino);
				vecinos[vecino].insert(i);
				j++;
			}
		}
		if( !(i % 10) ){
			gettimeofday(&tv,NULL);
			srand(tv.tv_usec);	
		}
	}
	
	for( int i = 0; i< nodos;i++ ){
		suma_grado += vecinos[i].size();
		if( vecinos[i].size() % 2 )
			return 1;
	}
	if( suma_grado == 0 )
		return 1;

	file_name = argv[1];
	file_name +=   "/eu." + convert.str()  + "." + argv[2] +  ".in";
	out.open(file_name.c_str());
	out << nodos << " ";
	out <<  (suma_grado /2) << endl;	
	out << tmp.rdbuf();
	out << "0" << endl;
	out.close();	
	cout << file_name << endl;
	return 0;
}
