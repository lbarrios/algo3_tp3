//#ifdef DEBUG
#include "DebugSingleton.h"
Debug *Debug::instance = NULL;

Debug::Debug( ostream& debug )
	:_debug(debug){
}

Debug::~Debug(){

}
//#endif