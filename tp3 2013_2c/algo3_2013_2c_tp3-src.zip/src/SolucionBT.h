
#ifndef __SolucionBT_H__
#define __SolucionBT_H__

#include "Solucion.h"

class SolucionBT: public Solucion {

	public:
		SolucionBT( Grafo &grafo );
		~SolucionBT();

		void resolver();
	private:
		void _resolverSolucionExactaBT(uint nodoActual);

  /**
   * Dada una cantidad de nodos devuelve el máximo
   * tamaño de frontera que se puede obtener con una clique
   * de ese tamaño
   */
  uint32_t _maximoTamanioFrontera ( uint32_t );

};

#endif
