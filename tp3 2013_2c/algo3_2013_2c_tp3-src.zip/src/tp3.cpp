#include "tp3.h"

int main( int argc, char** argv )
{
  ParserDeParametros parser( argc, argv );
  FactorySolucion *factory = NULL;
  uint32_t cantidadDeNodos;

  FactorySolucion::init();
  factory = FactorySolucion::getInstance();

  Debug::init( parser.tipoDebug() );

  parser.tipoInput() >> cantidadDeNodos;
  while( cantidadDeNodos )
  {
    // Obtengo grafo desde input que me dieron por parámetro
  	Grafo &grafo(leerGrafoDesdeInput(parser, cantidadDeNodos));

    // Instancio el tipo de solución desde parámetro
    Solucion *solucion = factory->crearSolucion(grafo, parser.tipoDeSolucion(),
      parser.tipoDeSolucionInicial(), parser.tabuMaxTamanio(), parser.tabuMaxIteraciones());
    // Resuelvo
    TOMAR_TIEMPO( solucion->resolver() );
    // Imprimo la solución hacia el output que me dieron por parámetro
#ifndef TIME
    imprimirOutput( parser.tipoOutput(), *solucion);
#else
    imprimirOutput( parser.tipoTime(), *solucion);
#endif

    // Borro instancia de Solucion
    delete solucion;
    // Libero la memoria del grafo
    delete &grafo;
    // Obtengo el próximo testcase
    parser.tipoInput() >> cantidadDeNodos;
  }

  FactorySolucion::end();
  return 0;
}

bool condicionParaUsarMatrizDeAdyacencia( FactorySolucion::TipoSolucion tipoDeSolucion )
{

  return
  (
    tipoDeSolucion == FactorySolucion::BACKTRACKING
  ||
    tipoDeSolucion == FactorySolucion::BUSQUEDA_LOCAL
  ||
    tipoDeSolucion == FactorySolucion::BUSQUEDA_TABU
  );

}

bool condicionParaUtilizarListasDeAdyacencia( FactorySolucion::TipoSolucion tipoDeSolucion )
{

  return
  (
    tipoDeSolucion == FactorySolucion::BACKTRACKING
  ||
    tipoDeSolucion == FactorySolucion::GREEDY
  ||
    tipoDeSolucion == FactorySolucion::BUSQUEDA_LOCAL
  ||
    tipoDeSolucion == FactorySolucion::BUSQUEDA_TABU
  );

}

Grafo& leerGrafoDesdeInput( ParserDeParametros &parser, uint cantidadDeNodos )
{
	/* Obtengo una referencia al input */
  istream &in = parser.tipoInput();

  /* Leo la cantidad de nodos y aristas */
  uint cantidadDeAristas;
  in >> cantidadDeAristas; DEBUGP(cantidadDeAristas);

  int tipoDeAlmacenamiento;
  /* Inicializo el grafo */
  if( condicionParaUsarMatrizDeAdyacencia( parser.tipoDeSolucion() ) )
  {
    if ( condicionParaUtilizarListasDeAdyacencia( parser.tipoDeSolucion() ) )
    {
      tipoDeAlmacenamiento = Grafo::MATRIZ_Y_LISTAS;
    }
    else
    {
      tipoDeAlmacenamiento = Grafo::MATRIZ_DE_ADYACENCIA;
    }
  }
  else
  {
    tipoDeAlmacenamiento = Grafo::LISTAS_DE_ADYACENCIA;
  }
  //if(_grafo) delete _grafo; // Libero memoria del grafo anterior
  Grafo *_grafo = new Grafo( cantidadDeNodos, tipoDeAlmacenamiento );;

  /* Leo y agrego las aristas */
  for(uint i=0; i<cantidadDeAristas; i++){
    uint nodoInicial, nodoFinal;
    in >> nodoInicial >> nodoFinal;
    _grafo->agregarArista(nodoInicial-1, nodoFinal-1);
    DEBUG2_PRINT("Agregando arista [" << nodoInicial << "," << nodoFinal << "]");
  }

  return *_grafo;
}

void imprimirOutput( ostream& out, Solucion &solucion )
{
  out << solucion.tamanioFrontera() << " " << solucion.tamanioClique() ;

  vector<uint32_t> nodosSolucion = solucion.nodosSolucion();
	vector<uint32_t>::iterator nodo = nodosSolucion.begin();
	while( nodo != nodosSolucion.end() ){
    out << " " << (*nodo)+1;
		nodo++;
  }

  out << endl;
}

